@echo off
cd /d "%~dp0"
title Medieval Map Editor

set "JAVA_CMD=java"
set "JAVAC_CMD=javac"

where java >nul 2>nul
if errorlevel 1 (
  if exist "C:\Program Files\Java\jdk-26.0.1\bin\java.exe" set "JAVA_CMD=C:\Program Files\Java\jdk-26.0.1\bin\java.exe"
)

where javac >nul 2>nul
if errorlevel 1 (
  if exist "C:\Program Files\Java\jdk-26.0.1\bin\javac.exe" set "JAVAC_CMD=C:\Program Files\Java\jdk-26.0.1\bin\javac.exe"
)

echo Kompiliere Editor...
if not exist "build\classes" mkdir "build\classes"
"%JAVAC_CMD%" -d "build\classes" "src\MedievalMapEditor.java"
if errorlevel 1 (
  echo.
  echo Kompilieren fehlgeschlagen.
  echo Bitte pruefe, ob ein Java JDK installiert ist.
  pause
  exit /b 1
)

echo Starte Editor...
"%JAVA_CMD%" -cp "build\classes" MedievalMapEditor
echo.
pause
