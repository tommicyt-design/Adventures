const TILE = 40;
const canvas = document.getElementById("mapCanvas");
const ctx = canvas.getContext("2d");

const terrainAssets = [
  { id: "grass", name: "Gras", color: "#4f7f3a" },
  { id: "path", name: "Weg", color: "#a27b48" },
  { id: "water", name: "Wasser", color: "#3c78a0" },
  { id: "stone", name: "Stein", color: "#77766f" },
  { id: "field", name: "Feld", color: "#8d7a37" },
  { id: "forest", name: "Waldboden", color: "#31502d" }
];

const objectAssets = [
  { id: "tree", name: "Baum", kind: "object", color: "#244c2c" },
  { id: "house", name: "Haus", kind: "object", color: "#a25837" },
  { id: "tavern", name: "Taverne", kind: "object", color: "#8f3b2f" },
  { id: "blacksmith", name: "Schmiede", kind: "object", color: "#6f4632" },
  { id: "well", name: "Brunnen", kind: "object", color: "#74848a" },
  { id: "chest", name: "Truhe", kind: "object", color: "#b4783d" },
  { id: "herb", name: "Heilkraut", kind: "object", color: "#77b95d" },
  { id: "log", name: "Holz", kind: "object", color: "#7b4a2c" },
  { id: "monster", name: "Monster", kind: "object", color: "#5c3f36" }
];

const tools = [
  { id: "paint", name: "Malen" },
  { id: "erase", name: "Radierer" },
  { id: "select", name: "Auswahl" },
  { id: "npc", name: "NPC setzen" }
];

let state = createDefaultState();
let currentTool = "paint";
let currentAsset = "grass";
let selection = null;
let activeQuestId = state.quests[0].id;
let isPointerDown = false;

function createDefaultState() {
  const width = 24;
  const height = 16;
  const terrain = Array.from({ length: height }, (_, y) =>
    Array.from({ length: width }, (_, x) => {
      if (x === 0 || y === 0 || x === width - 1 || y === height - 1) return "forest";
      if (y === 8 || x === 11) return "path";
      return "grass";
    })
  );

  return {
    version: 1,
    name: "Ritterdorf",
    width,
    height,
    terrain,
    objects: [
      { id: uid("obj"), type: "tavern", name: "Taverne", x: 4, y: 3 },
      { id: uid("obj"), type: "blacksmith", name: "Schmiede", x: 13, y: 3 },
      { id: uid("obj"), type: "well", name: "Dorfbrunnen", x: 11, y: 8 },
      { id: uid("obj"), type: "tree", name: "Alte Eiche", x: 2, y: 12 },
      { id: uid("obj"), type: "herb", name: "Heilkraut", x: 18, y: 11 }
    ],
    npcs: [
      {
        id: uid("npc"),
        name: "Habibi",
        x: 8,
        y: 7,
        color: "#6aa06d",
        dialogue: "Kannst du mir drei Heilkraeuter bringen?"
      },
      {
        id: uid("npc"),
        name: "Olaf",
        x: 15,
        y: 7,
        color: "#9d6b48",
        dialogue: "Die Schmiede braucht trockenes Holz."
      }
    ],
    quests: [
      {
        id: uid("quest"),
        title: "Heilkraeuter fuer Habibi",
        npcId: null,
        goal: "collect",
        target: "Heilkraut",
        amount: 3,
        rewardXp: 45,
        text: "Sammle drei Heilkraeuter am Dorfrand."
      }
    ]
  };
}

function uid(prefix) {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

function init() {
  state.quests[0].npcId = state.npcs[0].id;
  renderToolGrid();
  renderAssetGrids();
  bindEvents();
  syncAll();
}

function renderToolGrid() {
  const grid = document.getElementById("toolGrid");
  grid.innerHTML = "";
  tools.forEach((tool) => {
    const button = document.createElement("button");
    button.className = `tool ${tool.id === currentTool ? "active" : ""}`;
    button.textContent = tool.name;
    button.addEventListener("click", () => {
      currentTool = tool.id;
      renderToolGrid();
      setStatus();
    });
    grid.appendChild(button);
  });
}

function renderAssetGrids() {
  renderAssetGrid("terrainGrid", terrainAssets);
  renderAssetGrid("objectGrid", objectAssets);
}

function renderAssetGrid(elementId, assets) {
  const grid = document.getElementById(elementId);
  grid.innerHTML = "";
  assets.forEach((asset) => {
    const button = document.createElement("button");
    button.className = `asset ${asset.id === currentAsset ? "active" : ""}`;
    button.innerHTML = `<span class="swatch" style="background:${asset.color}"></span><span>${asset.name}</span>`;
    button.addEventListener("click", () => {
      currentAsset = asset.id;
      currentTool = terrainAssets.some((item) => item.id === asset.id) ? "paint" : "paint";
      renderToolGrid();
      renderAssetGrids();
      setStatus();
    });
    grid.appendChild(button);
  });
}

function bindEvents() {
  canvas.addEventListener("pointerdown", (event) => {
    isPointerDown = true;
    handleCanvas(event);
  });
  canvas.addEventListener("pointermove", (event) => {
    if (isPointerDown && currentTool !== "select" && currentTool !== "npc") handleCanvas(event);
  });
  window.addEventListener("pointerup", () => {
    isPointerDown = false;
  });

  document.getElementById("mapName").addEventListener("input", (event) => {
    state.name = event.target.value || "Unbenannte Karte";
    setStatus();
  });
  document.getElementById("resizeMap").addEventListener("click", resizeMap);
  document.getElementById("newMap").addEventListener("click", () => {
    state = createDefaultState();
    state.quests[0].npcId = state.npcs[0].id;
    activeQuestId = state.quests[0].id;
    selection = null;
    syncAll();
  });
  document.getElementById("exportMap").addEventListener("click", showExport);
  document.getElementById("copyJson").addEventListener("click", copyJson);
  document.getElementById("importMap").addEventListener("change", importMap);
  document.getElementById("closeExport").addEventListener("click", () => document.getElementById("exportDialog").close());

  document.getElementById("addNpc").addEventListener("click", addNpc);
  document.getElementById("addQuest").addEventListener("click", addQuest);
  document.getElementById("saveQuest").addEventListener("click", saveQuest);
  document.getElementById("deleteQuest").addEventListener("click", deleteQuest);
  document.getElementById("questSelect").addEventListener("change", (event) => {
    activeQuestId = event.target.value;
    fillQuestForm();
  });

  ["selectedName", "selectedX", "selectedY", "selectedDialogue"].forEach((id) => {
    document.getElementById(id).addEventListener("input", updateSelectionFromForm);
  });
  document.getElementById("deleteSelection").addEventListener("click", deleteSelection);
}

function handleCanvas(event) {
  const pos = getTileFromEvent(event);
  if (!pos) return;

  if (currentTool === "select") {
    selection = findEntityAt(pos.x, pos.y);
    syncSelection();
    draw();
    return;
  }

  if (currentTool === "erase") {
    removeAt(pos.x, pos.y);
    draw();
    syncLists();
    return;
  }

  if (currentTool === "npc") {
    createNpcAt(pos.x, pos.y);
    return;
  }

  if (terrainAssets.some((asset) => asset.id === currentAsset)) {
    state.terrain[pos.y][pos.x] = currentAsset;
  } else {
    const existing = state.objects.find((item) => item.x === pos.x && item.y === pos.y);
    if (existing) {
      existing.type = currentAsset;
      existing.name = assetName(currentAsset);
    } else {
      state.objects.push({ id: uid("obj"), type: currentAsset, name: assetName(currentAsset), x: pos.x, y: pos.y });
    }
  }
  draw();
}

function getTileFromEvent(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const x = Math.floor(((event.clientX - rect.left) * scaleX) / TILE);
  const y = Math.floor(((event.clientY - rect.top) * scaleY) / TILE);
  if (x < 0 || y < 0 || x >= state.width || y >= state.height) return null;
  return { x, y };
}

function findEntityAt(x, y) {
  const npc = state.npcs.find((item) => item.x === x && item.y === y);
  if (npc) return { kind: "npc", id: npc.id };
  const object = state.objects.find((item) => item.x === x && item.y === y);
  if (object) return { kind: "object", id: object.id };
  return null;
}

function removeAt(x, y) {
  state.objects = state.objects.filter((item) => item.x !== x || item.y !== y);
  state.npcs = state.npcs.filter((item) => item.x !== x || item.y !== y);
  if (selection) {
    const entity = getSelectedEntity();
    if (!entity) selection = null;
  }
}

function createNpcAt(x, y) {
  const npc = {
    id: uid("npc"),
    name: `NPC ${state.npcs.length + 1}`,
    x,
    y,
    color: "#6aa06d",
    dialogue: "Guten Tag, Reisender."
  };
  state.npcs.push(npc);
  selection = { kind: "npc", id: npc.id };
  syncAll();
}

function addNpc() {
  createNpcAt(Math.floor(state.width / 2), Math.floor(state.height / 2));
}

function addQuest() {
  const quest = {
    id: uid("quest"),
    title: `Quest ${state.quests.length + 1}`,
    npcId: state.npcs[0]?.id || "",
    goal: "collect",
    target: "Heilkraut",
    amount: 1,
    rewardXp: 25,
    text: "Beschreibe hier den Auftrag."
  };
  state.quests.push(quest);
  activeQuestId = quest.id;
  syncAll();
}

function saveQuest() {
  const quest = state.quests.find((item) => item.id === activeQuestId);
  if (!quest) return;
  quest.title = document.getElementById("questTitle").value;
  quest.npcId = document.getElementById("questNpc").value;
  quest.goal = document.getElementById("questGoal").value;
  quest.target = document.getElementById("questTarget").value;
  quest.amount = Number(document.getElementById("questAmount").value) || 1;
  quest.rewardXp = Number(document.getElementById("questReward").value) || 0;
  quest.text = document.getElementById("questText").value;
  syncLists();
  draw();
}

function deleteQuest() {
  if (!activeQuestId) return;
  state.quests = state.quests.filter((quest) => quest.id !== activeQuestId);
  activeQuestId = state.quests[0]?.id || "";
  syncAll();
}

function updateSelectionFromForm() {
  const entity = getSelectedEntity();
  if (!entity) return;
  entity.name = document.getElementById("selectedName").value;
  entity.x = clamp(Number(document.getElementById("selectedX").value), 0, state.width - 1);
  entity.y = clamp(Number(document.getElementById("selectedY").value), 0, state.height - 1);
  if (selection.kind === "npc") entity.dialogue = document.getElementById("selectedDialogue").value;
  syncLists();
  draw();
}

function deleteSelection() {
  if (!selection) return;
  if (selection.kind === "npc") {
    state.npcs = state.npcs.filter((item) => item.id !== selection.id);
    state.quests.forEach((quest) => {
      if (quest.npcId === selection.id) quest.npcId = "";
    });
  } else {
    state.objects = state.objects.filter((item) => item.id !== selection.id);
  }
  selection = null;
  syncAll();
}

function getSelectedEntity() {
  if (!selection) return null;
  const list = selection.kind === "npc" ? state.npcs : state.objects;
  return list.find((item) => item.id === selection.id) || null;
}

function resizeMap() {
  const width = clamp(Number(document.getElementById("mapWidth").value), 10, 60);
  const height = clamp(Number(document.getElementById("mapHeight").value), 8, 40);
  const nextTerrain = Array.from({ length: height }, (_, y) =>
    Array.from({ length: width }, (_, x) => state.terrain[y]?.[x] || "grass")
  );
  state.width = width;
  state.height = height;
  state.terrain = nextTerrain;
  state.objects = state.objects.filter((item) => item.x < width && item.y < height);
  state.npcs = state.npcs.filter((item) => item.x < width && item.y < height);
  selection = null;
  syncAll();
}

function syncAll() {
  document.getElementById("mapName").value = state.name;
  document.getElementById("mapWidth").value = state.width;
  document.getElementById("mapHeight").value = state.height;
  canvas.width = state.width * TILE;
  canvas.height = state.height * TILE;
  syncLists();
  syncSelection();
  fillQuestForm();
  setStatus();
  draw();
}

function syncLists() {
  renderList("npcList", state.npcs, (npc) => {
    selection = { kind: "npc", id: npc.id };
    syncSelection();
    draw();
  });
  renderList("questList", state.quests, (quest) => {
    activeQuestId = quest.id;
    fillQuestForm();
  }, (quest) => {
    const npc = state.npcs.find((item) => item.id === quest.npcId);
    return npc ? npc.name : "Kein NPC";
  });
  fillQuestOptions();
}

function renderList(id, items, onClick, subtitle = (item) => `${item.x}, ${item.y}`) {
  const list = document.getElementById(id);
  list.innerHTML = "";
  items.forEach((item) => {
    const button = document.createElement("button");
    button.className = "list-item";
    button.innerHTML = `<span>${item.name || item.title}<br><small>${subtitle(item)}</small></span><span>${item.rewardXp || ""}</span>`;
    button.addEventListener("click", () => onClick(item));
    list.appendChild(button);
  });
}

function syncSelection() {
  const entity = getSelectedEntity();
  document.getElementById("selectionEmpty").classList.toggle("hidden", Boolean(entity));
  document.getElementById("selectionForm").classList.toggle("hidden", !entity);
  if (!entity) return;
  document.getElementById("selectedKind").value = selection.kind === "npc" ? "NPC" : "Objekt";
  document.getElementById("selectedName").value = entity.name;
  document.getElementById("selectedX").value = entity.x;
  document.getElementById("selectedY").value = entity.y;
  document.getElementById("dialogueField").classList.toggle("hidden", selection.kind !== "npc");
  document.getElementById("selectedDialogue").value = entity.dialogue || "";
}

function fillQuestOptions() {
  const questSelect = document.getElementById("questSelect");
  const npcSelect = document.getElementById("questNpc");
  questSelect.innerHTML = "";
  npcSelect.innerHTML = '<option value="">Kein NPC</option>';
  state.quests.forEach((quest) => questSelect.add(new Option(quest.title, quest.id)));
  state.npcs.forEach((npc) => npcSelect.add(new Option(npc.name, npc.id)));
  if (!state.quests.some((quest) => quest.id === activeQuestId)) activeQuestId = state.quests[0]?.id || "";
  questSelect.value = activeQuestId;
}

function fillQuestForm() {
  fillQuestOptions();
  const quest = state.quests.find((item) => item.id === activeQuestId);
  const disabled = !quest;
  document.querySelectorAll("#questForm input, #questForm select, #questForm textarea, #saveQuest, #deleteQuest").forEach((el) => {
    el.disabled = disabled;
  });
  if (!quest) return;
  document.getElementById("questTitle").value = quest.title;
  document.getElementById("questNpc").value = quest.npcId || "";
  document.getElementById("questGoal").value = quest.goal;
  document.getElementById("questTarget").value = quest.target;
  document.getElementById("questAmount").value = quest.amount;
  document.getElementById("questReward").value = quest.rewardXp;
  document.getElementById("questText").value = quest.text;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let y = 0; y < state.height; y++) {
    for (let x = 0; x < state.width; x++) {
      drawTerrain(x, y, state.terrain[y][x]);
    }
  }
  state.objects.forEach(drawObject);
  state.npcs.forEach(drawNpc);
  drawGrid();
  drawSelection();
}

function drawTerrain(x, y, id) {
  const asset = terrainAssets.find((item) => item.id === id) || terrainAssets[0];
  ctx.fillStyle = asset.color;
  ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
  if (id === "path") {
    ctx.fillStyle = "rgba(80, 54, 30, 0.18)";
    ctx.fillRect(x * TILE + 4, y * TILE + 18, 32, 4);
  }
  if (id === "water") {
    ctx.strokeStyle = "rgba(212, 232, 235, 0.28)";
    ctx.beginPath();
    ctx.moveTo(x * TILE + 7, y * TILE + 14);
    ctx.quadraticCurveTo(x * TILE + 20, y * TILE + 9, x * TILE + 33, y * TILE + 14);
    ctx.stroke();
  }
  if (id === "field") {
    ctx.strokeStyle = "rgba(54, 37, 16, 0.22)";
    for (let i = 8; i < TILE; i += 9) {
      ctx.beginPath();
      ctx.moveTo(x * TILE + i, y * TILE + 3);
      ctx.lineTo(x * TILE + i - 4, y * TILE + 37);
      ctx.stroke();
    }
  }
}

function drawObject(item) {
  const px = item.x * TILE;
  const py = item.y * TILE;
  const selected = selection?.kind === "object" && selection.id === item.id;
  ctx.save();
  if (item.type === "tree") {
    ctx.fillStyle = "#5f3a20";
    ctx.fillRect(px + 17, py + 22, 7, 14);
    ctx.fillStyle = "#244c2c";
    circle(px + 20, py + 17, 15);
    ctx.fill();
  } else if (["house", "tavern", "blacksmith"].includes(item.type)) {
    ctx.fillStyle = item.type === "blacksmith" ? "#b99761" : "#d0a86f";
    ctx.fillRect(px + 7, py + 15, 26, 19);
    ctx.fillStyle = item.type === "tavern" ? "#8f3b2f" : item.type === "blacksmith" ? "#6f4632" : "#a25837";
    ctx.beginPath();
    ctx.moveTo(px + 4, py + 17);
    ctx.lineTo(px + 20, py + 5);
    ctx.lineTo(px + 36, py + 17);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#352319";
    ctx.fillRect(px + 17, py + 23, 7, 11);
  } else if (item.type === "well") {
    ctx.fillStyle = "#74848a";
    ctx.fillRect(px + 10, py + 18, 20, 13);
    ctx.fillStyle = "#3a4c56";
    ctx.fillRect(px + 13, py + 15, 14, 8);
  } else if (item.type === "chest") {
    ctx.fillStyle = "#b4783d";
    ctx.fillRect(px + 9, py + 18, 22, 15);
    ctx.fillStyle = "#55351e";
    ctx.fillRect(px + 18, py + 18, 4, 15);
  } else if (item.type === "herb") {
    ctx.strokeStyle = "#bce58b";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(px + 20, py + 30);
    ctx.lineTo(px + 20, py + 14);
    ctx.moveTo(px + 20, py + 22);
    ctx.lineTo(px + 11, py + 16);
    ctx.moveTo(px + 20, py + 22);
    ctx.lineTo(px + 29, py + 16);
    ctx.stroke();
  } else if (item.type === "log") {
    ctx.fillStyle = "#7b4a2c";
    ctx.fillRect(px + 9, py + 19, 22, 9);
    ctx.strokeStyle = "#c18b54";
    ctx.strokeRect(px + 9, py + 19, 22, 9);
  } else if (item.type === "monster") {
    ctx.fillStyle = "#5c3f36";
    circle(px + 20, py + 21, 13);
    ctx.fill();
    ctx.fillStyle = "#e5c35b";
    circle(px + 15, py + 18, 2);
    circle(px + 25, py + 18, 2);
    ctx.fill();
  }
  ctx.restore();
  if (selected) drawBox(px, py, "#f2d371");
}

function drawNpc(npc) {
  const px = npc.x * TILE;
  const py = npc.y * TILE;
  const selected = selection?.kind === "npc" && selection.id === npc.id;
  ctx.fillStyle = npc.color || "#6aa06d";
  circle(px + 20, py + 18, 10);
  ctx.fill();
  ctx.fillStyle = "#2b1b12";
  ctx.fillRect(px + 13, py + 27, 14, 8);
  ctx.fillStyle = "#f4d57c";
  ctx.font = "bold 15px Segoe UI";
  ctx.textAlign = "center";
  ctx.fillText("!", px + 20, py + 9);
  if (selected) drawBox(px, py, "#f2d371");
}

function drawGrid() {
  ctx.strokeStyle = "rgba(26, 21, 14, 0.36)";
  ctx.lineWidth = 1;
  for (let x = 0; x <= state.width; x++) {
    ctx.beginPath();
    ctx.moveTo(x * TILE, 0);
    ctx.lineTo(x * TILE, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y <= state.height; y++) {
    ctx.beginPath();
    ctx.moveTo(0, y * TILE);
    ctx.lineTo(canvas.width, y * TILE);
    ctx.stroke();
  }
}

function drawSelection() {
  const entity = getSelectedEntity();
  if (!entity) return;
  drawBox(entity.x * TILE, entity.y * TILE, "#f2d371");
}

function drawBox(px, py, color) {
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.strokeRect(px + 2, py + 2, TILE - 4, TILE - 4);
}

function circle(x, y, r) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
}

function showExport() {
  document.getElementById("exportText").value = JSON.stringify(state, null, 2);
  document.getElementById("exportDialog").showModal();
}

async function copyJson() {
  const json = JSON.stringify(state, null, 2);
  try {
    await navigator.clipboard.writeText(json);
    document.getElementById("statusLine").textContent = "JSON wurde kopiert.";
  } catch {
    document.getElementById("exportText").value = json;
    document.getElementById("exportDialog").showModal();
  }
}

function importMap(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      state = normalizeImported(imported);
      activeQuestId = state.quests[0]?.id || "";
      selection = null;
      syncAll();
    } catch {
      alert("Die JSON-Datei konnte nicht geladen werden.");
    }
  };
  reader.readAsText(file);
  event.target.value = "";
}

function normalizeImported(data) {
  const width = clamp(Number(data.width) || 24, 10, 60);
  const height = clamp(Number(data.height) || 16, 8, 40);
  const terrain = Array.from({ length: height }, (_, y) =>
    Array.from({ length: width }, (_, x) => data.terrain?.[y]?.[x] || "grass")
  );
  return {
    version: 1,
    name: data.name || "Importierte Karte",
    width,
    height,
    terrain,
    objects: Array.isArray(data.objects) ? data.objects : [],
    npcs: Array.isArray(data.npcs) ? data.npcs : [],
    quests: Array.isArray(data.quests) ? data.quests : []
  };
}

function assetName(id) {
  return [...terrainAssets, ...objectAssets].find((asset) => asset.id === id)?.name || id;
}

function setStatus() {
  document.getElementById("statusTitle").textContent = state.name;
  document.getElementById("statusLine").textContent = `${tools.find((tool) => tool.id === currentTool).name}: ${assetName(currentAsset)}`;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

init();
