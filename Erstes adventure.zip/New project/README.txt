Ritterdorf Quest - Projektstruktur

Spiel starten:
- SpielStarten.bat

Editor starten:
- EditorStarten.bat

Ordner:
- src/             Java-Quellcode fuer Spiel und Editor
- build/classes/   Kompilierte Java-Dateien (.class)
- Maps/            Gespeicherte Karten als JSON
- Texturen/        Eigene Texturen und Bilddateien
- saves/           Spielstaende
- web-archive/     Alte HTML/JavaScript-Version als Archiv

Hinweis:
Die Startdateien kompilieren den Java-Code automatisch und starten danach das Spiel bzw. den Editor.
