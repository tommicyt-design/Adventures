import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

public class MedievalMapEditor {
  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> new EditorFrame().setVisible(true));
  }
}

class EditorFrame extends JFrame {
  private final EditorState state = new EditorState();
  private final MapCanvas canvas;
  private final DefaultListModel<Asset> assetModel = new DefaultListModel<>();
  private final DefaultListModel<NpcData> npcModel = new DefaultListModel<>();
  private final DefaultListModel<QuestData> questModel = new DefaultListModel<>();
  private final JList<Asset> assetList = new JList<>(assetModel);
  private final JList<NpcData> npcList = new JList<>(npcModel);
  private final JList<QuestData> questList = new JList<>(questModel);
  private final JTextField mapName = new JTextField(state.mapName);
  private final JTextField npcName = new JTextField();
  private final JTextArea npcDialog = new JTextArea(3, 18);
  private final JTextField questTitle = new JTextField();
  private final JTextArea questText = new JTextArea(3, 18);
  private final JComboBox<String> questGoal = new JComboBox<>(new String[] {"Sammeln", "Mit NPC sprechen", "Ort erreichen", "Monster besiegen"});
  private final JTextField questTarget = new JTextField();
  private final JTextField questAmount = new JTextField("3");
  private final JTextField questReward = new JTextField("45");

  EditorFrame() {
    super("Medieval Top Down Map Editor");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(1240, 780);
    setLocationRelativeTo(null);

    state.createStarterMap();
    canvas = new MapCanvas(state, this::loadModels);
    loadModels();

    assetList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    assetList.setSelectedIndex(0);
    assetList.addListSelectionListener(e -> {
      state.selectedAsset = assetList.getSelectedValue();
      canvas.repaint();
    });
    state.selectedAsset = assetList.getSelectedValue();

    npcList.addListSelectionListener(e -> fillNpcForm());
    questList.addListSelectionListener(e -> fillQuestForm());

    JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel(), centerPanel());
    split.setDividerLocation(280);
    JSplitPane root = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, split, rightPanel());
    root.setDividerLocation(940);
    add(root, BorderLayout.CENTER);
  }

  private JPanel leftPanel() {
    JPanel panel = darkPanel(new BorderLayout(8, 8));
    panel.setPreferredSize(new Dimension(280, 700));

    JPanel top = darkPanel(new GridLayout(0, 1, 6, 6));
    top.add(label("Karte"));
    top.add(mapName);

    JButton paint = new JButton("Malen");
    JButton erase = new JButton("Radierer");
    JButton select = new JButton("Auswahl");
    JButton npc = new JButton("NPC setzen");
    paint.addActionListener(e -> state.tool = Tool.PAINT);
    erase.addActionListener(e -> state.tool = Tool.ERASE);
    select.addActionListener(e -> state.tool = Tool.SELECT);
    npc.addActionListener(e -> state.tool = Tool.NPC);
    top.add(paint);
    top.add(erase);
    top.add(select);
    top.add(npc);

    JButton addTexture = new JButton("Eigene Textur laden");
    addTexture.addActionListener(e -> loadCustomTexture());
    top.add(addTexture);

    panel.add(top, BorderLayout.NORTH);
    panel.add(new JScrollPane(assetList), BorderLayout.CENTER);

    JPanel bottom = darkPanel(new GridLayout(0, 1, 6, 6));
    JButton save = new JButton("Map als JSON speichern");
    JButton load = new JButton("JSON laden");
    save.addActionListener(e -> saveMap());
    load.addActionListener(e -> loadMap());
    bottom.add(save);
    bottom.add(load);
    panel.add(bottom, BorderLayout.SOUTH);
    return panel;
  }

  private JPanel centerPanel() {
    JPanel panel = darkPanel(new BorderLayout());
    JScrollPane scroll = new JScrollPane(canvas);
    scroll.getViewport().setBackground(new Color(17, 19, 15));
    panel.add(scroll, BorderLayout.CENTER);
    JLabel hint = label("Linksklick malt/setzt. Mit Auswahl anklicken, dann rechts bearbeiten. Eigene Texturen: PNG/JPG laden und wie Assets benutzen.");
    hint.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
    panel.add(hint, BorderLayout.SOUTH);
    return panel;
  }

  private JPanel rightPanel() {
    JPanel panel = darkPanel(new GridLayout(0, 1, 8, 8));
    panel.setPreferredSize(new Dimension(300, 700));

    panel.add(label("NPCs"));
    panel.add(new JScrollPane(npcList));
    panel.add(label("NPC Name"));
    panel.add(npcName);
    panel.add(label("NPC Dialog"));
    panel.add(new JScrollPane(npcDialog));
    JButton saveNpc = new JButton("NPC speichern");
    JButton deleteNpc = new JButton("NPC loeschen");
    saveNpc.addActionListener(e -> saveNpc());
    deleteNpc.addActionListener(e -> deleteNpc());
    panel.add(saveNpc);
    panel.add(deleteNpc);

    panel.add(label("Quests"));
    panel.add(new JScrollPane(questList));
    JButton addQuest = new JButton("Quest hinzufuegen");
    addQuest.addActionListener(e -> addQuest());
    panel.add(addQuest);
    panel.add(label("Quest Titel"));
    panel.add(questTitle);
    panel.add(label("Ziel"));
    panel.add(questGoal);
    panel.add(label("Zieltext"));
    panel.add(questTarget);

    JPanel numbers = darkPanel(new GridLayout(1, 2, 6, 6));
    numbers.add(questAmount);
    numbers.add(questReward);
    panel.add(label("Menge / XP"));
    panel.add(numbers);
    panel.add(label("Beschreibung"));
    panel.add(new JScrollPane(questText));
    JButton saveQuest = new JButton("Quest speichern");
    JButton deleteQuest = new JButton("Quest loeschen");
    saveQuest.addActionListener(e -> saveQuest());
    deleteQuest.addActionListener(e -> deleteQuest());
    panel.add(saveQuest);
    panel.add(deleteQuest);
    return panel;
  }

  private void loadCustomTexture() {
    JFileChooser chooser = new JFileChooser();
    chooser.setFileFilter(new FileNameExtensionFilter("Bilddateien", "png", "jpg", "jpeg", "gif"));
    if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

    File file = chooser.getSelectedFile();
    String name = JOptionPane.showInputDialog(this, "Name der Textur:", stripExtension(file.getName()));
    if (name == null || name.trim().isEmpty()) return;

    String[] options = {"Terrain-Tile", "Objekt"};
    int choice = JOptionPane.showOptionDialog(this, "Als Terrain oder Objekt benutzen?", "Texturtyp",
        JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
    if (choice < 0) return;

    try {
      BufferedImage image = ImageIO.read(file);
      if (image == null) throw new IOException("Nicht lesbares Bild");
      Asset asset = new Asset("custom_" + System.nanoTime(), name.trim(), choice == 0 ? AssetKind.TERRAIN : AssetKind.OBJECT,
          new Color(120, 105, 70), file.getAbsolutePath(), image);
      state.assets.add(asset);
      assetModel.addElement(asset);
      assetList.setSelectedValue(asset, true);
      state.selectedAsset = asset;
      canvas.repaint();
    } catch (IOException ex) {
      JOptionPane.showMessageDialog(this, "Textur konnte nicht geladen werden:\n" + ex.getMessage());
    }
  }

  private void saveMap() {
    state.mapName = mapName.getText().trim().isEmpty() ? "Unbenannte Karte" : mapName.getText().trim();
    File mapsDir = new File("Maps");
    mapsDir.mkdirs();
    JFileChooser chooser = new JFileChooser(mapsDir);
    chooser.setSelectedFile(new File(state.mapName.replaceAll("[^A-Za-z0-9_-]", "_") + ".json"));
    if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
    try {
      Files.writeString(chooser.getSelectedFile().toPath(), state.toJson(), StandardCharsets.UTF_8);
    } catch (IOException ex) {
      JOptionPane.showMessageDialog(this, "Speichern fehlgeschlagen:\n" + ex.getMessage());
    }
  }

  private void loadMap() {
    JFileChooser chooser = new JFileChooser(new File("Maps"));
    chooser.setFileFilter(new FileNameExtensionFilter("JSON Maps", "json"));
    if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
    try {
      state.fromJson(Files.readString(chooser.getSelectedFile().toPath(), StandardCharsets.UTF_8));
      loadModels();
      mapName.setText(state.mapName);
      canvas.repaint();
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(this, "Laden fehlgeschlagen:\n" + ex.getMessage());
    }
  }

  private void loadModels() {
    assetModel.clear();
    npcModel.clear();
    questModel.clear();
    for (Asset asset : state.assets) assetModel.addElement(asset);
    for (NpcData npc : state.npcs) npcModel.addElement(npc);
    for (QuestData quest : state.quests) questModel.addElement(quest);
  }

  private void fillNpcForm() {
    NpcData npc = npcList.getSelectedValue();
    if (npc == null) return;
    npcName.setText(npc.name);
    npcDialog.setText(npc.dialog);
    state.selectedNpc = npc;
    canvas.repaint();
  }

  private void saveNpc() {
    NpcData npc = npcList.getSelectedValue();
    if (npc == null) return;
    npc.name = npcName.getText().trim().isEmpty() ? "NPC" : npcName.getText().trim();
    npc.dialog = npcDialog.getText();
    npcList.repaint();
    canvas.repaint();
  }

  private void deleteNpc() {
    NpcData npc = npcList.getSelectedValue();
    if (npc == null) return;
    state.npcs.remove(npc);
    npcModel.removeElement(npc);
    state.selectedNpc = null;
    canvas.repaint();
  }

  private void addQuest() {
    QuestData quest = new QuestData("Neue Quest", "Sammeln", "Heilkraut", 1, 25, "Beschreibe den Auftrag.");
    state.quests.add(quest);
    questModel.addElement(quest);
    questList.setSelectedValue(quest, true);
  }

  private void fillQuestForm() {
    QuestData quest = questList.getSelectedValue();
    if (quest == null) return;
    questTitle.setText(quest.title);
    questGoal.setSelectedItem(quest.goal);
    questTarget.setText(quest.target);
    questAmount.setText(String.valueOf(quest.amount));
    questReward.setText(String.valueOf(quest.rewardXp));
    questText.setText(quest.text);
  }

  private void saveQuest() {
    QuestData quest = questList.getSelectedValue();
    if (quest == null) return;
    quest.title = questTitle.getText().trim().isEmpty() ? "Quest" : questTitle.getText().trim();
    quest.goal = String.valueOf(questGoal.getSelectedItem());
    quest.target = questTarget.getText();
    quest.amount = parseInt(questAmount.getText(), 1);
    quest.rewardXp = parseInt(questReward.getText(), 0);
    quest.text = questText.getText();
    questList.repaint();
  }

  private void deleteQuest() {
    QuestData quest = questList.getSelectedValue();
    if (quest == null) return;
    state.quests.remove(quest);
    questModel.removeElement(quest);
  }

  private static JPanel darkPanel(java.awt.LayoutManager layout) {
    JPanel panel = new JPanel(layout);
    panel.setBackground(new Color(36, 32, 24));
    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    return panel;
  }

  private static JLabel label(String text) {
    JLabel label = new JLabel(text);
    label.setForeground(new Color(238, 226, 205));
    return label;
  }

  private static int parseInt(String text, int fallback) {
    try {
      return Integer.parseInt(text.trim());
    } catch (NumberFormatException ex) {
      return fallback;
    }
  }

  private static String stripExtension(String value) {
    int dot = value.lastIndexOf('.');
    return dot > 0 ? value.substring(0, dot) : value;
  }
}

class MapCanvas extends JPanel {
  private static final int TILE = 40;
  private final EditorState state;
  private final Runnable onModelChange;

  MapCanvas(EditorState state, Runnable onModelChange) {
    this.state = state;
    this.onModelChange = onModelChange;
    setPreferredSize(new Dimension(state.width * TILE, state.height * TILE));
    setBackground(new Color(21, 23, 18));

    MouseAdapter mouse = new MouseAdapter() {
      @Override public void mousePressed(MouseEvent e) {
        applyAt(e.getPoint());
      }

      @Override public void mouseDragged(MouseEvent e) {
        if (state.tool == Tool.PAINT || state.tool == Tool.ERASE) applyAt(e.getPoint());
      }
    };
    addMouseListener(mouse);
    addMouseMotionListener(mouse);
  }

  private void applyAt(Point point) {
    int x = point.x / TILE;
    int y = point.y / TILE;
    if (x < 0 || y < 0 || x >= state.width || y >= state.height) return;

    if (state.tool == Tool.SELECT) {
      state.selectedNpc = findNpc(x, y);
      state.selectedObject = findObject(x, y);
      repaint();
      return;
    }

    if (state.tool == Tool.ERASE) {
      boolean changedNpc = state.npcs.removeIf(item -> item.x == x && item.y == y);
      state.objects.removeIf(item -> item.x == x && item.y == y);
      if (changedNpc) onModelChange.run();
      repaint();
      return;
    }

    if (state.tool == Tool.NPC) {
      NpcData npc = new NpcData("NPC " + (state.npcs.size() + 1), x, y, "Guten Tag, Reisender.");
      state.npcs.add(npc);
      state.selectedNpc = npc;
      onModelChange.run();
      repaint();
      return;
    }

    Asset asset = state.selectedAsset;
    if (asset == null) return;
    if (asset.kind == AssetKind.TERRAIN) {
      state.tiles[y][x] = asset.id;
    } else {
      state.objects.removeIf(item -> item.x == x && item.y == y);
      state.objects.add(new ObjectData(asset.id, asset.name, x, y));
    }
    repaint();
  }

  @Override protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g.create();
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

    for (int y = 0; y < state.height; y++) {
      for (int x = 0; x < state.width; x++) {
        drawAsset(g2, state.findAsset(state.tiles[y][x]), x, y);
      }
    }

    for (ObjectData object : state.objects) {
      drawObject(g2, object);
    }
    for (NpcData npc : state.npcs) {
      drawNpc(g2, npc);
    }
    drawGrid(g2);
    g2.dispose();
  }

  private void drawAsset(Graphics2D g, Asset asset, int x, int y) {
    int px = x * TILE;
    int py = y * TILE;
    if (asset != null && asset.image != null) {
      g.drawImage(asset.image, px, py, TILE, TILE, null);
    } else {
      g.setColor(asset == null ? new Color(77, 124, 58) : asset.color);
      g.fillRect(px, py, TILE, TILE);
    }
  }

  private void drawObject(Graphics2D g, ObjectData object) {
    Asset asset = state.findAsset(object.assetId);
    int px = object.x * TILE;
    int py = object.y * TILE;
    if (asset != null && asset.image != null) {
      g.drawImage(asset.image, px + 2, py + 2, TILE - 4, TILE - 4, null);
      return;
    }

    String id = asset == null ? object.assetId : asset.id;
    if ("tree".equals(id)) {
      g.setColor(new Color(91, 58, 31));
      g.fillRect(px + 17, py + 22, 7, 14);
      g.setColor(new Color(37, 76, 44));
      g.fillOval(px + 6, py + 4, 28, 26);
    } else if ("house".equals(id) || "tavern".equals(id) || "blacksmith".equals(id)) {
      g.setColor(new Color(204, 168, 111));
      g.fillRect(px + 7, py + 15, 26, 20);
      g.setColor("blacksmith".equals(id) ? new Color(111, 70, 50) : new Color(162, 88, 55));
      int[] xs = {px + 4, px + 20, px + 36};
      int[] ys = {py + 17, py + 5, py + 17};
      g.fillPolygon(xs, ys, 3);
      g.setColor(new Color(52, 35, 25));
      g.fillRect(px + 17, py + 24, 7, 11);
    } else if ("well".equals(id)) {
      g.setColor(new Color(116, 132, 138));
      g.fillRect(px + 10, py + 18, 20, 13);
      g.setColor(new Color(58, 76, 86));
      g.fillRect(px + 13, py + 15, 14, 8);
    } else {
      g.setColor(asset == null ? new Color(180, 120, 65) : asset.color);
      g.fillOval(px + 8, py + 8, 24, 24);
    }
  }

  private void drawNpc(Graphics2D g, NpcData npc) {
    int px = npc.x * TILE;
    int py = npc.y * TILE;
    g.setColor(new Color(106, 160, 109));
    g.fillOval(px + 10, py + 7, 20, 22);
    g.setColor(new Color(43, 27, 18));
    g.fillRect(px + 14, py + 27, 12, 8);
    g.setColor(new Color(244, 213, 124));
    g.setFont(new Font("Dialog", Font.BOLD, 15));
    g.drawString("!", px + 17, py + 9);
    if (state.selectedNpc == npc) {
      g.setColor(new Color(245, 215, 120));
      g.setStroke(new BasicStroke(3));
      g.drawRect(px + 2, py + 2, TILE - 4, TILE - 4);
    }
  }

  private void drawGrid(Graphics2D g) {
    g.setColor(new Color(24, 20, 14, 90));
    for (int x = 0; x <= state.width; x++) g.drawLine(x * TILE, 0, x * TILE, state.height * TILE);
    for (int y = 0; y <= state.height; y++) g.drawLine(0, y * TILE, state.width * TILE, y * TILE);
  }

  private NpcData findNpc(int x, int y) {
    for (NpcData npc : state.npcs) if (npc.x == x && npc.y == y) return npc;
    return null;
  }

  private ObjectData findObject(int x, int y) {
    for (ObjectData object : state.objects) if (object.x == x && object.y == y) return object;
    return null;
  }
}

enum Tool { PAINT, ERASE, SELECT, NPC }
enum AssetKind { TERRAIN, OBJECT }

class EditorState {
  int width = 24;
  int height = 16;
  String mapName = "Ritterdorf";
  String[][] tiles = new String[height][width];
  Tool tool = Tool.PAINT;
  Asset selectedAsset;
  NpcData selectedNpc;
  ObjectData selectedObject;
  final List<Asset> assets = new ArrayList<>();
  final List<ObjectData> objects = new ArrayList<>();
  final List<NpcData> npcs = new ArrayList<>();
  final List<QuestData> quests = new ArrayList<>();

  void createStarterMap() {
    assets.clear();
    objects.clear();
    npcs.clear();
    quests.clear();
    assets.add(new Asset("grass", "Gras", AssetKind.TERRAIN, new Color(79, 127, 58), null, null));
    assets.add(new Asset("path", "Weg", AssetKind.TERRAIN, new Color(162, 123, 72), null, null));
    assets.add(new Asset("water", "Wasser", AssetKind.TERRAIN, new Color(60, 120, 160), null, null));
    assets.add(new Asset("forest", "Waldboden", AssetKind.TERRAIN, new Color(49, 80, 45), null, null));
    assets.add(new Asset("tree", "Baum", AssetKind.OBJECT, new Color(37, 76, 44), null, null));
    assets.add(new Asset("house", "Haus", AssetKind.OBJECT, new Color(162, 88, 55), null, null));
    assets.add(new Asset("tavern", "Taverne", AssetKind.OBJECT, new Color(143, 59, 47), null, null));
    assets.add(new Asset("blacksmith", "Schmiede", AssetKind.OBJECT, new Color(111, 70, 50), null, null));
    assets.add(new Asset("well", "Brunnen", AssetKind.OBJECT, new Color(116, 132, 138), null, null));
    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        tiles[y][x] = x == 0 || y == 0 || x == width - 1 || y == height - 1 ? "forest" : "grass";
        if (x == 11 || y == 8) tiles[y][x] = "path";
      }
    }
    objects.add(new ObjectData("tavern", "Taverne", 4, 3));
    objects.add(new ObjectData("blacksmith", "Schmiede", 13, 3));
    objects.add(new ObjectData("well", "Dorfbrunnen", 11, 8));
    npcs.add(new NpcData("Habibi", 8, 7, "Kannst du mir drei Heilkraeuter bringen?"));
    npcs.add(new NpcData("Olaf", 15, 7, "Die Schmiede braucht trockenes Holz."));
    quests.add(new QuestData("Heilkraeuter fuer Habibi", "Sammeln", "Heilkraut", 3, 45, "Sammle drei Heilkraeuter am Dorfrand."));
  }

  Asset findAsset(String id) {
    for (Asset asset : assets) if (asset.id.equals(id)) return asset;
    return null;
  }

  String toJson() {
    StringBuilder json = new StringBuilder();
    json.append("{\n");
    json.append("  \"name\": \"").append(escape(mapName)).append("\",\n");
    json.append("  \"width\": ").append(width).append(",\n");
    json.append("  \"height\": ").append(height).append(",\n");
    json.append("  \"assets\": [\n");
    for (int i = 0; i < assets.size(); i++) {
      Asset a = assets.get(i);
      json.append("    {\"id\":\"").append(escape(a.id)).append("\",\"name\":\"").append(escape(a.name))
          .append("\",\"kind\":\"").append(a.kind).append("\",\"texturePath\":\"").append(escape(a.texturePath == null ? "" : a.texturePath)).append("\"}");
      json.append(i + 1 < assets.size() ? ",\n" : "\n");
    }
    json.append("  ],\n");
    json.append("  \"tiles\": [\n");
    for (int y = 0; y < height; y++) {
      json.append("    [");
      for (int x = 0; x < width; x++) {
        json.append("\"").append(escape(tiles[y][x])).append("\"");
        if (x + 1 < width) json.append(",");
      }
      json.append(y + 1 < height ? "],\n" : "]\n");
    }
    json.append("  ],\n");
    json.append("  \"objects\": [\n");
    for (int i = 0; i < objects.size(); i++) {
      ObjectData o = objects.get(i);
      json.append("    {\"assetId\":\"").append(escape(o.assetId)).append("\",\"name\":\"").append(escape(o.name))
          .append("\",\"x\":").append(o.x).append(",\"y\":").append(o.y).append("}");
      json.append(i + 1 < objects.size() ? ",\n" : "\n");
    }
    json.append("  ],\n");
    json.append("  \"npcs\": [\n");
    for (int i = 0; i < npcs.size(); i++) {
      NpcData n = npcs.get(i);
      json.append("    {\"name\":\"").append(escape(n.name)).append("\",\"x\":").append(n.x).append(",\"y\":").append(n.y)
          .append(",\"dialog\":\"").append(escape(n.dialog)).append("\"}");
      json.append(i + 1 < npcs.size() ? ",\n" : "\n");
    }
    json.append("  ],\n");
    json.append("  \"quests\": [\n");
    for (int i = 0; i < quests.size(); i++) {
      QuestData q = quests.get(i);
      json.append("    {\"title\":\"").append(escape(q.title)).append("\",\"goal\":\"").append(escape(q.goal))
          .append("\",\"target\":\"").append(escape(q.target)).append("\",\"amount\":").append(q.amount)
          .append(",\"rewardXp\":").append(q.rewardXp).append(",\"text\":\"").append(escape(q.text)).append("\"}");
      json.append(i + 1 < quests.size() ? ",\n" : "\n");
    }
    json.append("  ]\n");
    json.append("}\n");
    return json.toString();
  }

  void fromJson(String json) throws IOException {
    createStarterMap();
    mapName = matchString(json, "name", mapName);
    width = matchInt(json, "width", width);
    height = matchInt(json, "height", height);
    tiles = new String[height][width];
    for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) tiles[y][x] = "grass";

    assets.clear();
    String assetsBlock = matchBlock(json, "assets");
    for (String item : objectSnippets(assetsBlock)) {
      String id = matchString(item, "id", "asset_" + assets.size());
      String name = matchString(item, "name", id);
      AssetKind kind = "OBJECT".equals(matchString(item, "kind", "TERRAIN")) ? AssetKind.OBJECT : AssetKind.TERRAIN;
      String path = matchString(item, "texturePath", "");
      BufferedImage image = null;
      if (!path.isEmpty()) {
        File file = new File(path);
        if (file.isFile()) image = ImageIO.read(file);
      }
      assets.add(new Asset(id, name, kind, new Color(120, 105, 70), path.isEmpty() ? null : path, image));
    }

    String tileBlock = matchBlock(json, "tiles");
    Matcher rowMatcher = Pattern.compile("\\[(.*?)\\]", Pattern.DOTALL).matcher(tileBlock);
    int y = 0;
    while (rowMatcher.find() && y < height) {
      Matcher tileMatcher = Pattern.compile("\"(.*?)\"").matcher(rowMatcher.group(1));
      int x = 0;
      while (tileMatcher.find() && x < width) tiles[y][x++] = unescape(tileMatcher.group(1));
      y++;
    }

    objects.clear();
    for (String item : objectSnippets(matchBlock(json, "objects"))) {
      objects.add(new ObjectData(matchString(item, "assetId", "tree"), matchString(item, "name", "Objekt"),
          matchInt(item, "x", 0), matchInt(item, "y", 0)));
    }
    npcs.clear();
    for (String item : objectSnippets(matchBlock(json, "npcs"))) {
      npcs.add(new NpcData(matchString(item, "name", "NPC"), matchInt(item, "x", 0), matchInt(item, "y", 0),
          matchString(item, "dialog", "")));
    }
    quests.clear();
    for (String item : objectSnippets(matchBlock(json, "quests"))) {
      quests.add(new QuestData(matchString(item, "title", "Quest"), matchString(item, "goal", "Sammeln"),
          matchString(item, "target", ""), matchInt(item, "amount", 1), matchInt(item, "rewardXp", 0),
          matchString(item, "text", "")));
    }
  }

  private static List<String> objectSnippets(String block) {
    List<String> snippets = new ArrayList<>();
    Matcher matcher = Pattern.compile("\\{(.*?)\\}", Pattern.DOTALL).matcher(block);
    while (matcher.find()) snippets.add(matcher.group(1));
    return snippets;
  }

  private static String matchBlock(String json, String key) {
    String token = "\"" + key + "\"";
    int keyIndex = json.indexOf(token);
    if (keyIndex < 0) return "";
    int start = json.indexOf('[', keyIndex + token.length());
    if (start < 0) return "";
    int depth = 0;
    boolean inString = false;
    boolean escaped = false;
    for (int i = start; i < json.length(); i++) {
      char c = json.charAt(i);
      if (escaped) {
        escaped = false;
      } else if (c == '\\') {
        escaped = true;
      } else if (c == '"') {
        inString = !inString;
      } else if (!inString && c == '[') {
        depth++;
      } else if (!inString && c == ']') {
        depth--;
        if (depth == 0) return json.substring(start + 1, i);
      }
    }
    return "";
  }

  private static String matchString(String json, String key, String fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(json);
    return matcher.find() ? unescape(matcher.group(1)) : fallback;
  }

  private static int matchInt(String json, String key, int fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*(\\d+)").matcher(json);
    return matcher.find() ? Integer.parseInt(matcher.group(1)) : fallback;
  }

  private static String escape(String value) {
    return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
  }

  private static String unescape(String value) {
    return value.replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\");
  }
}

class Asset {
  final String id;
  final String name;
  final AssetKind kind;
  final Color color;
  final String texturePath;
  final Image image;

  Asset(String id, String name, AssetKind kind, Color color, String texturePath, Image image) {
    this.id = id;
    this.name = name;
    this.kind = kind;
    this.color = color;
    this.texturePath = texturePath;
    this.image = image;
  }

  @Override public String toString() {
    return (kind == AssetKind.TERRAIN ? "Terrain: " : "Objekt: ") + name;
  }
}

class ObjectData {
  final String assetId;
  String name;
  int x;
  int y;

  ObjectData(String assetId, String name, int x, int y) {
    this.assetId = assetId;
    this.name = name;
    this.x = x;
    this.y = y;
  }
}

class NpcData {
  String name;
  int x;
  int y;
  String dialog;

  NpcData(String name, int x, int y, String dialog) {
    this.name = name;
    this.x = x;
    this.y = y;
    this.dialog = dialog;
  }

  @Override public String toString() {
    return name + " (" + x + ", " + y + ")";
  }
}

class QuestData {
  String title;
  String goal;
  String target;
  int amount;
  int rewardXp;
  String text;

  QuestData(String title, String goal, String target, int amount, int rewardXp, String text) {
    this.title = title;
    this.goal = goal;
    this.target = target;
    this.amount = amount;
    this.rewardXp = rewardXp;
    this.text = text;
  }

  @Override public String toString() {
    return title + " +" + rewardXp + " XP";
  }
}
