import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

public class MedievalQuestGame {
  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
      JFrame frame = new JFrame("Ritterdorf Quest");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setResizable(false);
      frame.setContentPane(new StartMenuPanel(frame));
      frame.pack();
      frame.setLocationRelativeTo(null);
      frame.setVisible(true);
    });
  }

  static void startGame(JFrame frame, PlayableWorld world) {
    startGame(frame, world, null);
  }

  static void startGame(JFrame frame, PlayableWorld world, SaveGame save) {
    GamePanel panel = new GamePanel(frame, world, save);
    frame.setContentPane(panel);
    frame.pack();
    frame.setLocationRelativeTo(null);
    panel.requestFocusInWindow();
  }
}

class StartMenuPanel extends JPanel {
  private final JFrame frame;
  private final DefaultListModel<File> worlds = new DefaultListModel<>();
  private final JList<File> worldList = new JList<>(worlds);

  StartMenuPanel(JFrame frame) {
    this.frame = frame;
    setPreferredSize(new Dimension(960, 640));
    setLayout(new BorderLayout(20, 20));
    setBackground(new Color(23, 20, 15));
    setBorder(BorderFactory.createEmptyBorder(44, 56, 44, 56));

    JLabel title = new JLabel("Ritterdorf Quest");
    title.setForeground(new Color(245, 213, 125));
    title.setFont(new Font("Dialog", Font.BOLD, 42));
    add(title, BorderLayout.NORTH);

    worldList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    worldList.setCellRenderer((list, value, index, selected, focus) -> {
      JLabel label = new JLabel(value.getName());
      label.setOpaque(true);
      label.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
      label.setForeground(new Color(242, 234, 216));
      label.setBackground(selected ? new Color(90, 72, 45) : new Color(36, 32, 24));
      return label;
    });
    refreshWorlds();

    JPanel center = new JPanel(new BorderLayout(10, 10));
    center.setOpaque(false);
    JLabel hint = new JLabel("Waehle eine gespeicherte Editor-Welt oder starte die Standardwelt.");
    hint.setForeground(new Color(183, 170, 145));
    center.add(hint, BorderLayout.NORTH);
    center.add(new JScrollPane(worldList), BorderLayout.CENTER);
    add(center, BorderLayout.CENTER);

    JPanel actions = new JPanel(new GridLayout(1, 5, 10, 10));
    actions.setOpaque(false);
    JButton standard = menuButton("Standardwelt");
    JButton selected = menuButton("Auswahl spielen");
    JButton browse = menuButton("JSON suchen");
    JButton refresh = menuButton("Aktualisieren");
    JButton loadSave = menuButton("Spielstand laden");
    standard.addActionListener(e -> MedievalQuestGame.startGame(frame, null));
    selected.addActionListener(e -> playSelected());
    browse.addActionListener(e -> browseWorld());
    refresh.addActionListener(e -> refreshWorlds());
    loadSave.addActionListener(e -> loadSaveGame());
    actions.add(standard);
    actions.add(selected);
    actions.add(browse);
    actions.add(refresh);
    actions.add(loadSave);
    add(actions, BorderLayout.SOUTH);
  }

  private JButton menuButton(String text) {
    JButton button = new JButton(text);
    button.setBackground(new Color(54, 45, 32));
    button.setForeground(new Color(242, 234, 216));
    button.setFocusPainted(false);
    return button;
  }

  private void refreshWorlds() {
    worlds.clear();
    File[] files = new File("Maps").listFiles((dir, name) -> name.toLowerCase().endsWith(".json"));
    if (files == null) return;
    for (File file : files) worlds.addElement(file);
    if (!worlds.isEmpty()) worldList.setSelectedIndex(0);
  }

  private void playSelected() {
    File file = worldList.getSelectedValue();
    if (file == null) {
      JOptionPane.showMessageDialog(this, "Speichere zuerst im Editor eine JSON-Welt oder nutze 'JSON suchen'.");
      return;
    }
    loadAndStart(file);
  }

  private void browseWorld() {
    JFileChooser chooser = new JFileChooser(new File("Maps"));
    if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
    loadAndStart(chooser.getSelectedFile());
  }

  private void loadAndStart(File file) {
    try {
      MedievalQuestGame.startGame(frame, PlayableWorldLoader.load(file));
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(this, "Welt konnte nicht geladen werden:\n" + ex.getMessage());
    }
  }

  private void loadSaveGame() {
    File saveFile = new File("saves", "savegame.json");
    if (!saveFile.isFile()) {
      JOptionPane.showMessageDialog(this, "Es gibt noch keinen gespeicherten Spielstand.");
      return;
    }
    try {
      SaveGame save = SaveGame.load(saveFile);
      PlayableWorld world = save.worldPath.isEmpty() ? null : PlayableWorldLoader.load(new File(save.worldPath));
      MedievalQuestGame.startGame(frame, world, save);
    } catch (Exception ex) {
      JOptionPane.showMessageDialog(this, "Spielstand konnte nicht geladen werden:\n" + ex.getMessage());
    }
  }
}

class GamePanel extends JPanel {
  private static final int WIDTH = 960;
  private static final int HEIGHT = 640;
  private static final int TILE = 32;

  private final Set<Integer> keys = new HashSet<>();
  private final JFrame ownerFrame;
  private final Player player = new Player(470, 340);
  private final List<Building> buildings = new ArrayList<>();
  private final List<Npc> npcs = new ArrayList<>();
  private final List<Item> herbs = new ArrayList<>();
  private final List<Item> logs = new ArrayList<>();
  private final List<Monster> monsters = new ArrayList<>();
  private final List<VisualEffect> effects = new ArrayList<>();
  private final SoundManager sound = new SoundManager();
  private final PlayableWorld customWorld;
  private final JPanel pauseMenu = new JPanel(new GridLayout(0, 1, 8, 8));
  private final int[][] villageTrees = {
      {78, 80}, {144, 112}, {835, 98}, {890, 160}, {62, 500}, {118, 554},
      {810, 520}, {888, 566}, {730, 62}, {236, 548}, {672, 576}
  };
  private final int[][] forestTrees = {
      {72, 82}, {124, 150}, {90, 254}, {150, 420}, {82, 548}, {244, 94},
      {310, 170}, {265, 326}, {318, 520}, {468, 88}, {512, 240}, {460, 435},
      {632, 130}, {700, 292}, {626, 514}, {812, 92}, {870, 185}, {825, 448}
  };

  private Scene scene = Scene.VILLAGE;
  private Building currentBuilding;
  private String title = "Sprich mit einem Dorfbewohner";
  private String message = "WASD/Pfeile bewegen, E interagieren, F angreifen.";
  private int messageTimer = 0;
  private int frame = 0;
  private Timer gameTimer;
  private boolean interactPressed = false;
  private boolean attackPressed = false;
  private boolean escapePressed = false;
  private boolean menuOpen = false;

  GamePanel(JFrame ownerFrame, PlayableWorld customWorld, SaveGame save) {
    this.ownerFrame = ownerFrame;
    this.customWorld = customWorld;
    setPreferredSize(new Dimension(WIDTH, HEIGHT));
    setFocusable(true);
    setLayout(null);
    setBackground(new Color(23, 20, 15));

    if (customWorld != null) {
      loadCustomWorld();
    } else {
      loadDefaultWorld();
    }
    if (save != null) applySave(save);
    createPauseMenu();

    addKeyListener(new KeyAdapter() {
      @Override public void keyPressed(KeyEvent e) {
        keys.add(e.getKeyCode());
      }

      @Override public void keyReleased(KeyEvent e) {
        keys.remove(e.getKeyCode());
      }
    });

    gameTimer = new Timer(16, e -> tick());
    gameTimer.start();
  }

  private void loadDefaultWorld() {
    buildings.add(new Building(112, 122, 142, 104, "Taverne", new Color(143, 59, 47), new Color(199, 165, 109)));
    buildings.add(new Building(372, 86, 152, 112, "Schmiede", new Color(113, 66, 47), new Color(185, 145, 95)));
    buildings.add(new Building(675, 122, 144, 105, "Stall", new Color(155, 81, 50), new Color(209, 176, 113)));
    buildings.add(new Building(205, 410, 135, 100, "Muehle", new Color(127, 60, 56), new Color(200, 157, 102)));
    buildings.add(new Building(610, 398, 150, 108, "Kapelle", new Color(111, 75, 46), new Color(196, 163, 109)));

    npcs.add(new Npc("Habibi", "Heilkraeuter fuer Habibi", "Sammle 3 Heilkraeuter am Dorfrand.", 304, 238, new Color(106, 160, 109), 45, QuestType.HERBS));
    npcs.add(new Npc("Olaf", "Holz fuer die Schmiede", "Bring Olaf 2 Holzscheite.", 580, 255, new Color(157, 107, 72), 60, QuestType.WOOD));
    npcs.add(new Npc("Bruenhilde", "Wache am Brunnen", "Patrouilliere zum Brunnen in der Dorfmitte.", 515, 428, new Color(103, 126, 181), 35, QuestType.WELL));

    herbs.add(new Item(250, 190));
    herbs.add(new Item(702, 212));
    herbs.add(new Item(176, 430));
    herbs.add(new Item(604, 470));
    logs.add(new Item(105, 295));
    logs.add(new Item(760, 360));
    logs.add(new Item(824, 448));

    monsters.add(new Monster("Waldwicht", 260, 170, 15, 2, 25, new Color(127, 75, 57)));
    monsters.add(new Monster("Schattenwolf", 560, 305, 17, 3, 40, new Color(61, 67, 80)));
    monsters.add(new Monster("Dornenling", 350, 490, 16, 2, 30, new Color(77, 112, 65)));
    monsters.add(new Monster("Mooskoloss", 720, 430, 20, 4, 55, new Color(93, 111, 69)));
  }

  private void loadCustomWorld() {
    title = customWorld.name;
    message = "WASD/Pfeile bewegen, E mit NPCs sprechen, F angreifen.";
    player.x = WIDTH / 2.0;
    player.y = HEIGHT / 2.0;
    for (int i = 0; i < customWorld.npcs.size(); i++) {
      WorldNpc worldNpc = customWorld.npcs.get(i);
      WorldQuest quest = i < customWorld.quests.size() ? customWorld.quests.get(i) : null;
      String questTitle = quest == null ? worldNpc.name : quest.title;
      String questText = quest == null ? worldNpc.dialog : quest.text;
      int reward = quest == null ? 10 : quest.rewardXp;
      npcs.add(new Npc(worldNpc.name, questTitle, questText, worldNpc.pixelX(), worldNpc.pixelY(),
          new Color(106, 160, 109), reward, QuestType.TALK));
    }
    for (WorldObject object : customWorld.objects) {
      if ("monster".equals(object.assetId)) {
        monsters.add(new Monster(object.name, object.pixelX(), object.pixelY(), 16, 2, 25, new Color(92, 63, 54)));
      } else if ("herb".equals(object.assetId)) {
        herbs.add(new Item(object.pixelX(), object.pixelY()));
      } else if ("log".equals(object.assetId)) {
        logs.add(new Item(object.pixelX(), object.pixelY()));
      }
    }
  }

  private void createPauseMenu() {
    pauseMenu.setBounds(WIDTH / 2 - 150, HEIGHT / 2 - 150, 300, 300);
    pauseMenu.setBackground(new Color(36, 32, 24));
    pauseMenu.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(new Color(217, 173, 85), 2),
        BorderFactory.createEmptyBorder(16, 16, 16, 16)));
    pauseMenu.setVisible(false);

    JLabel menuTitle = new JLabel("Ingame Menue", JLabel.CENTER);
    menuTitle.setForeground(new Color(245, 213, 125));
    menuTitle.setFont(new Font("Dialog", Font.BOLD, 20));
    pauseMenu.add(menuTitle);

    JButton resume = menuButton("Weiter");
    JButton save = menuButton("Speichern");
    JButton soundToggle = menuButton("Sound: An");
    JButton worldSelect = menuButton("Zur Weltauswahl");
    JButton exit = menuButton("Spiel beenden");
    resume.addActionListener(e -> {
      sound.play("menu");
      toggleMenu(false);
    });
    save.addActionListener(e -> saveGame());
    soundToggle.addActionListener(e -> {
      sound.toggle();
      soundToggle.setText(sound.isEnabled() ? "Sound: An" : "Sound: Aus");
      sound.play("menu");
      requestFocusInWindow();
    });
    worldSelect.addActionListener(e -> {
      sound.play("menu");
      backToWorldSelect();
    });
    exit.addActionListener(e -> {
      sound.play("menu");
      System.exit(0);
    });
    pauseMenu.add(resume);
    pauseMenu.add(save);
    pauseMenu.add(soundToggle);
    pauseMenu.add(worldSelect);
    pauseMenu.add(exit);
    add(pauseMenu);
  }

  private JButton menuButton(String text) {
    JButton button = new JButton(text);
    button.setBackground(new Color(54, 45, 32));
    button.setForeground(new Color(242, 234, 216));
    button.setFocusPainted(false);
    return button;
  }

  private void tick() {
    if (keys.contains(KeyEvent.VK_ESCAPE)) {
      if (!escapePressed) toggleMenu(!menuOpen);
      escapePressed = true;
    } else {
      escapePressed = false;
    }

    if (menuOpen) {
      repaint();
      return;
    }

    frame++;
    updateEffects();
    movePlayer();
    updateMonsters();

    if (keys.contains(KeyEvent.VK_E)) {
      if (!interactPressed) interact();
      interactPressed = true;
    } else {
      interactPressed = false;
    }

    if (keys.contains(KeyEvent.VK_F)) {
      if (!attackPressed) attack();
      attackPressed = true;
    } else {
      attackPressed = false;
    }

    if (messageTimer > 0) {
      messageTimer--;
    } else {
      Npc quest = activeQuest();
      if (quest != null) {
        title = quest.title;
        message = quest.text + " Inventar: " + player.herbs + " Heilkraut, " + player.wood + " Holz.";
      } else if (scene == Scene.FOREST) {
        title = "Westwald";
        message = "Besiege Monster mit F oder gehe rechts zurueck ins Dorf.";
      } else if (customWorld != null) {
        title = customWorld.name;
        message = "Erkunde deine Welt. Mit E sprichst du mit NPCs.";
      } else {
        title = "Ritterdorf";
        message = "Links liegt der Westwald. Im Dorf kannst du Quests mit E annehmen.";
      }
    }

    repaint();
  }

  private void toggleMenu(boolean open) {
    menuOpen = open;
    pauseMenu.setVisible(open);
    if (open) sound.play("menu");
    if (!open) requestFocusInWindow();
    repaint();
  }

  private void saveGame() {
    try {
      SaveGame save = new SaveGame();
      save.worldPath = customWorld == null || customWorld.sourcePath == null ? "" : customWorld.sourcePath;
      save.scene = scene.name();
      save.playerX = player.x;
      save.playerY = player.y;
      save.herbs = player.herbs;
      save.wood = player.wood;
      save.xp = player.xp;
      save.nextXp = player.nextXp;
      save.level = player.level;
      File saveFile = new File("saves", "savegame.json");
      Files.createDirectories(saveFile.getParentFile().toPath());
      Files.writeString(saveFile.toPath(), save.toJson(), StandardCharsets.UTF_8);
      sound.play("save");
      addEffect(player.x, player.y - 22, new Color(120, 200, 255), "SAVE");
      setMessage("Gespeichert", "Dein Spielstand wurde in saves/savegame.json gespeichert.", 3);
      toggleMenu(false);
    } catch (IOException ex) {
      JOptionPane.showMessageDialog(this, "Speichern fehlgeschlagen:\n" + ex.getMessage());
    }
  }

  private void backToWorldSelect() {
    if (gameTimer != null) gameTimer.stop();
    ownerFrame.setContentPane(new StartMenuPanel(ownerFrame));
    ownerFrame.pack();
    ownerFrame.setLocationRelativeTo(null);
  }

  private void applySave(SaveGame save) {
    player.x = save.playerX;
    player.y = save.playerY;
    player.herbs = save.herbs;
    player.wood = save.wood;
    player.xp = save.xp;
    player.nextXp = save.nextXp;
    player.level = save.level;
    try {
      scene = Scene.valueOf(save.scene);
    } catch (IllegalArgumentException ex) {
      scene = Scene.VILLAGE;
    }
    title = "Spielstand geladen";
    message = "Dein gespeicherter Fortschritt wurde geladen.";
    messageTimer = 3 * 60;
  }

  private void movePlayer() {
    double dx = 0;
    double dy = 0;
    if (keys.contains(KeyEvent.VK_LEFT) || keys.contains(KeyEvent.VK_A)) dx -= 1;
    if (keys.contains(KeyEvent.VK_RIGHT) || keys.contains(KeyEvent.VK_D)) dx += 1;
    if (keys.contains(KeyEvent.VK_UP) || keys.contains(KeyEvent.VK_W)) dy -= 1;
    if (keys.contains(KeyEvent.VK_DOWN) || keys.contains(KeyEvent.VK_S)) dy += 1;

    if (dx != 0 || dy != 0) {
      double len = Math.hypot(dx, dy);
      player.vx = dx / len;
      player.vy = dy / len;
      player.facingX = player.vx;
      player.facingY = player.vy;
      player.moving = true;
      player.walkCycle += 0.32;
      moveBy(player.vx * player.speed, player.vy * player.speed);
    } else {
      player.vx = 0;
      player.vy = 0;
      player.moving = false;
      player.walkCycle *= 0.82;
    }

    if (player.interactAnim > 0) player.interactAnim--;
    if (player.attackAnim > 0) player.attackAnim--;
  }

  private void moveBy(double dx, double dy) {
    if (customWorld != null) {
      double nx = clamp(player.x + dx, player.r, WIDTH - player.r);
      if (canStandAt(nx, player.y)) player.x = nx;
      double ny = clamp(player.y + dy, player.r + 66, HEIGHT - 72 - player.r);
      if (canStandAt(player.x, ny)) player.y = ny;
      return;
    }

    if (scene == Scene.VILLAGE && dx < 0 && player.x + dx <= player.r + 2) {
      enterForest();
      return;
    }
    if (scene == Scene.FOREST && dx > 0 && player.x + dx >= WIDTH - player.r - 2) {
      enterVillageFromForest();
      return;
    }

    double minX = scene == Scene.INSIDE ? 120 : player.r;
    double maxX = scene == Scene.INSIDE ? WIDTH - 120 : WIDTH - player.r;
    double minY = scene == Scene.INSIDE ? 92 : player.r;
    double maxY = scene == Scene.INSIDE ? HEIGHT - 72 : HEIGHT - player.r;

    double nx = clamp(player.x + dx, minX, maxX);
    if (canStandAt(nx, player.y)) player.x = nx;
    double ny = clamp(player.y + dy, minY, maxY);
    if (canStandAt(player.x, ny)) player.y = ny;
  }

  private boolean canStandAt(double x, double y) {
    if (scene != Scene.VILLAGE) return true;
    for (Building b : buildings) {
      if (circleHitsRect(x, y, player.r, b.x, b.y, b.w, b.h)) return false;
    }
    return true;
  }

  private void interact() {
    player.interactAnim = 18;
    sound.play("interact");

    if (scene == Scene.INSIDE) {
      if (dist(player.x, player.y, WIDTH / 2.0, HEIGHT - 74) < 50) exitBuilding();
      else setMessage(currentBuilding.name, "Hier drinnen ist es ruhig. Die Tuer ist unten im Raum.", 3);
      return;
    }

    Building door = nearestDoor();
    if (door != null) {
      enterBuilding(door);
      return;
    }

    Npc npc = nearestNpc();
    if (npc != null) {
      if (npc.state == QuestState.AVAILABLE) {
        npc.state = QuestState.ACTIVE;
        setMessage(npc.title, npc.text + " Kehre dann zu " + npc.name + " zurueck.", 5);
      } else if (npc.state == QuestState.ACTIVE) {
        if (questDone(npc)) completeQuest(npc, npc.name + " dankt dir.");
        else setMessage(npc.title, "Noch nicht fertig: " + npc.text, 4);
      } else {
        setMessage(npc.name, "Danke fuer deine Hilfe, tapferer Ritter.", 3);
      }
      return;
    }

    Npc quest = activeQuest();
    if (quest != null && quest.type == QuestType.WELL && questDone(quest)) {
      completeQuest(quest, "Du hast am Brunnen Wache gehalten.");
      return;
    }

    for (Item herb : herbs) {
      if (!herb.taken && dist(player.x, player.y, herb.x, herb.y) < 34) {
        herb.taken = true;
        player.herbs++;
        sound.play("pickup");
        addEffect(herb.x, herb.y, new Color(136, 211, 107), "+Kraut");
        setMessage("Heilkraut gesammelt", "Du hast " + player.herbs + " Heilkraut bei dir.", 3);
        return;
      }
    }
    for (Item log : logs) {
      if (!log.taken && dist(player.x, player.y, log.x, log.y) < 34) {
        log.taken = true;
        player.wood++;
        sound.play("pickup");
        addEffect(log.x, log.y, new Color(185, 130, 76), "+Holz");
        setMessage("Holz aufgenommen", "Du traegst " + player.wood + " Holzscheit(e).", 3);
        return;
      }
    }
  }

  private void attack() {
    if (scene == Scene.INSIDE) return;
    player.attackAnim = 16;
    sound.play("attack");
    addEffect(player.x + player.facingX * 34, player.y + player.facingY * 24, new Color(245, 213, 125), "SLASH");
    boolean hit = false;

    if (scene == Scene.FOREST || customWorld != null) {
      for (Monster monster : monsters) {
        if (monster.hp <= 0) continue;
        double dx = monster.x - player.x;
        double dy = monster.y - player.y;
        double range = Math.hypot(dx, dy);
        double aimedAt = (dx * player.facingX + dy * player.facingY) / Math.max(range, 1);
        if (range < 58 && aimedAt > 0.25) {
          monster.hp--;
          monster.hit = 12;
          hit = true;
          sound.play("hit");
          addEffect(monster.x, monster.y, new Color(235, 95, 75), "HIT");
          if (monster.hp <= 0) {
            gainXp(monster.xp);
            sound.play("quest");
            addEffect(monster.x, monster.y, new Color(245, 213, 125), "+" + monster.xp + " XP");
            setMessage("Monster besiegt", monster.name + " wurde besiegt. +" + monster.xp + " XP erhalten.", 4);
          } else {
            setMessage("Treffer", monster.name + " hat noch " + monster.hp + " Trefferpunkt(e).", 2);
          }
          break;
        }
      }
      if (!hit) setMessage("Schwertschlag", "Dein Schlag trifft nur die Waldluft.", 2);
    }
  }

  private void updateMonsters() {
    if (scene != Scene.FOREST && customWorld == null) return;
    for (Monster monster : monsters) {
      if (monster.hp <= 0) continue;
      if (monster.hit > 0) monster.hit--;
      double toPlayer = dist(monster.x, monster.y, player.x, player.y);
      double tx = toPlayer < 170 ? player.x : monster.homeX;
      double ty = toPlayer < 170 ? player.y : monster.homeY;
      double dx = tx - monster.x;
      double dy = ty - monster.y;
      double len = Math.hypot(dx, dy);
      if (len > 3) {
        double speed = toPlayer < 170 ? 0.7 : 0.35;
        monster.x += dx / len * speed;
        monster.y += dy / len * speed;
      }
    }
  }

  private void updateEffects() {
    for (int i = effects.size() - 1; i >= 0; i--) {
      VisualEffect effect = effects.get(i);
      effect.age++;
      effect.y -= 0.45;
      if (effect.age >= effect.life) effects.remove(i);
    }
  }

  private void addEffect(double x, double y, Color color, String text) {
    effects.add(new VisualEffect(x, y, color, text));
  }

  private void enterBuilding(Building building) {
    currentBuilding = building;
    scene = Scene.INSIDE;
    player.x = WIDTH / 2.0;
    player.y = HEIGHT - 112;
    player.facingX = 0;
    player.facingY = -1;
    setMessage(building.name, "Du bist eingetreten. Unten an der Tuer kommst du wieder raus.", 4);
  }

  private void exitBuilding() {
    scene = Scene.VILLAGE;
    player.x = currentBuilding.x + currentBuilding.w / 2.0;
    player.y = currentBuilding.y + currentBuilding.h + 34;
    player.facingX = 0;
    player.facingY = 1;
    setMessage(currentBuilding.name, "Du bist wieder im Dorf.", 3);
    currentBuilding = null;
  }

  private void enterForest() {
    scene = Scene.FOREST;
    player.x = WIDTH - 46;
    player.y = clamp(player.y, player.r, HEIGHT - player.r);
    player.facingX = -1;
    player.facingY = 0;
    sound.play("transition");
    addEffect(player.x, player.y, new Color(87, 141, 84), "Wald");
    setMessage("Westwald", "Du betrittst den Wald. Greife Monster mit F an. Rechts geht es zurueck ins Dorf.", 5);
  }

  private void enterVillageFromForest() {
    scene = Scene.VILLAGE;
    player.x = 46;
    player.y = clamp(player.y, player.r, HEIGHT - player.r);
    player.facingX = 1;
    player.facingY = 0;
    sound.play("transition");
    addEffect(player.x, player.y, new Color(217, 173, 85), "Dorf");
    setMessage("Dorf", "Du bist aus dem Wald ins Dorf zurueckgekehrt.", 3);
  }

  private Npc nearestNpc() {
    if (scene != Scene.VILLAGE && customWorld == null) return null;
    for (Npc npc : npcs) {
      if (dist(player.x, player.y, npc.x, npc.y) < 46) return npc;
    }
    return null;
  }

  private Building nearestDoor() {
    if (scene != Scene.VILLAGE) return null;
    for (Building b : buildings) {
      if (dist(player.x, player.y, b.x + b.w / 2.0, b.y + b.h - 16) < 44) return b;
    }
    return null;
  }

  private Npc activeQuest() {
    for (Npc npc : npcs) {
      if (npc.state == QuestState.ACTIVE) return npc;
    }
    return null;
  }

  private boolean questDone(Npc npc) {
    if (npc.type == QuestType.TALK) return true;
    if (npc.type == QuestType.HERBS) return player.herbs >= 3;
    if (npc.type == QuestType.WOOD) return player.wood >= 2;
    return dist(player.x, player.y, 480, 316) < 54;
  }

  private void completeQuest(Npc npc, String text) {
    if (npc.type == QuestType.HERBS) player.herbs -= 3;
    if (npc.type == QuestType.WOOD) player.wood -= 2;
    npc.state = QuestState.COMPLETE;
    gainXp(npc.reward);
    sound.play("quest");
    addEffect(player.x, player.y - 28, new Color(245, 213, 125), "QUEST");
    setMessage("Quest abgeschlossen", text + " +" + npc.reward + " XP erhalten.", 5);
  }

  private void gainXp(int amount) {
    player.xp += amount;
    while (player.xp >= player.nextXp) {
      player.xp -= player.nextXp;
      player.level++;
      player.nextXp = Math.round(player.nextXp * 1.35f);
      player.speed += 0.18;
      sound.play("level");
      addEffect(player.x, player.y - 38, new Color(120, 200, 255), "LEVEL " + player.level);
      setMessage("Levelaufstieg!", "Du bist jetzt Level " + player.level + ".", 5);
    }
  }

  private void setMessage(String newTitle, String newMessage, int seconds) {
    title = newTitle;
    message = newMessage;
    messageTimer = seconds * 60;
  }

  @Override protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);

    if (customWorld != null) {
      drawCustomWorld(g2);
      for (Monster monster : monsters) drawMonster(g2, monster);
    } else if (scene == Scene.INSIDE) {
      drawInterior(g2);
    } else if (scene == Scene.FOREST) {
      drawForest(g2);
      for (Monster monster : monsters) drawMonster(g2, monster);
    } else {
      drawVillage(g2);
    }

    drawEffects(g2);
    drawPlayer(g2);
    drawHint(g2);
    drawHud(g2);
    if (menuOpen) drawPauseShade(g2);
  }

  private void drawEffects(Graphics2D g) {
    for (VisualEffect effect : effects) {
      double progress = effect.age / (double) effect.life;
      int alpha = (int) (220 * (1.0 - progress));
      int radius = 8 + (int) (progress * 28);
      int x = (int) Math.round(effect.x);
      int y = (int) Math.round(effect.y);
      g.setColor(new Color(effect.color.getRed(), effect.color.getGreen(), effect.color.getBlue(), Math.max(0, alpha)));
      g.setStroke(new BasicStroke(2));
      g.drawOval(x - radius, y - radius, radius * 2, radius * 2);
      if (!effect.text.isEmpty()) {
        g.setFont(new Font("Dialog", Font.BOLD, 13));
        drawCentered(g, effect.text, x, y - radius - 4);
      }
    }
  }

  private void drawPauseShade(Graphics2D g) {
    g.setColor(new Color(0, 0, 0, 120));
    g.fillRect(0, 0, WIDTH, HEIGHT);
  }

  private void drawVillage(Graphics2D g) {
    pixelTileFill(g, new Color(81, 110, 60), new Color(92, 126, 67));
    drawPath(g, 0, 292, WIDTH, 52);
    drawPath(g, 454, 0, 52, HEIGHT);
    drawWestGate(g);
    for (Building b : buildings) drawBuilding(g, b);
    drawWell(g);
    drawItems(g);
    for (int[] t : villageTrees) drawTree(g, t[0], t[1]);
    for (Npc npc : npcs) drawNpc(g, npc);
  }

  private void drawCustomWorld(Graphics2D g) {
    int offsetX = 0;
    int offsetY = 72;
    g.setColor(new Color(18, 19, 15));
    g.fillRect(0, 0, WIDTH, HEIGHT);
    for (int y = 0; y < customWorld.height; y++) {
      for (int x = 0; x < customWorld.width; x++) {
        drawWorldAsset(g, customWorld.asset(customWorld.tiles[y][x]), offsetX + x * TILE, offsetY + y * TILE);
      }
    }
    for (WorldObject object : customWorld.objects) {
      if ("monster".equals(object.assetId) || "herb".equals(object.assetId) || "log".equals(object.assetId)) continue;
      drawWorldObject(g, object, offsetX + object.x * TILE, offsetY + object.y * TILE);
    }
    drawItems(g);
    for (Npc npc : npcs) drawNpc(g, npc);
  }

  private void drawWorldAsset(Graphics2D g, WorldAsset asset, int x, int y) {
    if (asset != null && asset.image != null) {
      g.drawImage(asset.image, x, y, TILE, TILE, null);
      return;
    }
    g.setColor(asset == null ? new Color(81, 110, 60) : asset.color);
    g.fillRect(x, y, TILE, TILE);
    g.setColor(new Color(0, 0, 0, 24));
    g.drawRect(x, y, TILE, TILE);
  }

  private void drawWorldObject(Graphics2D g, WorldObject object, int x, int y) {
    WorldAsset asset = customWorld.asset(object.assetId);
    if (asset != null && asset.image != null) {
      g.drawImage(asset.image, x, y, TILE, TILE, null);
      return;
    }
    if ("tree".equals(object.assetId)) drawTree(g, x + 16, y + 16);
    else if ("well".equals(object.assetId)) {
      g.setColor(new Color(116, 132, 138));
      g.fillRect(x + 8, y + 16, 18, 14);
      g.setColor(new Color(58, 76, 86));
      g.fillRect(x + 11, y + 12, 12, 8);
    } else {
      Building visual = new Building(x + 2, y + 5, 28, 24, object.name, new Color(143, 59, 47), new Color(199, 165, 109));
      drawBuilding(g, visual);
    }
  }

  private void drawForest(Graphics2D g) {
    pixelTileFill(g, new Color(38, 63, 42), new Color(49, 79, 49));
    drawPath(g, 0, 340, WIDTH, 56);
    g.setColor(new Color(70, 97, 48));
    for (int x = 16; x < WIDTH; x += 96) {
      g.fillRect(x, 96 + (x % 160), 18, 18);
      g.fillRect(x + 34, 250 + (x % 120), 14, 14);
    }
    g.setColor(new Color(241, 221, 181));
    g.setFont(new Font("Dialog", Font.BOLD, 13));
    g.drawString("Dorf", WIDTH - 50, 250);
    for (int[] t : forestTrees) drawTree(g, t[0], t[1]);
  }

  private void drawInterior(Graphics2D g) {
    Color floor = currentBuilding == null ? new Color(93, 62, 42) : currentBuilding.wall.darker();
    g.setColor(new Color(23, 18, 13));
    g.fillRect(0, 0, WIDTH, HEIGHT);
    g.setColor(floor);
    g.fillRect(96, 70, WIDTH - 192, HEIGHT - 120);
    g.setColor(new Color(168, 137, 86));
    g.setStroke(new BasicStroke(8));
    g.drawRect(96, 70, WIDTH - 192, HEIGHT - 120);
    for (int x = 116; x < WIDTH - 110; x += 48) {
      g.setColor(new Color(255, 255, 255, 18));
      g.fillRect(x, 90, 3, HEIGHT - 160);
    }
    g.setColor(new Color(110, 71, 40));
    g.fillRect(180, 146, 116, 54);
    g.setColor(new Color(48, 37, 27));
    g.fillRect(190, 156, 96, 34);
    g.setColor(new Color(43, 26, 16));
    g.fillRect(WIDTH / 2 - 26, HEIGHT - 112, 52, 42);
    g.setColor(new Color(245, 213, 125));
    g.fillRect(WIDTH / 2 - 18, HEIGHT - 98, 36, 10);
    g.setColor(new Color(241, 221, 181));
    g.setFont(new Font("Dialog", Font.BOLD, 16));
    drawCentered(g, currentBuilding == null ? "Haus" : currentBuilding.name, WIDTH / 2, 42);
  }

  private void pixelTileFill(Graphics2D g, Color a, Color b) {
    for (int y = 0; y < HEIGHT; y += TILE) {
      for (int x = 0; x < WIDTH; x += TILE) {
        g.setColor(((x / TILE + y / TILE) & 1) == 0 ? a : b);
        g.fillRect(x, y, TILE, TILE);
        g.setColor(new Color(0, 0, 0, 18));
        g.drawRect(x, y, TILE, TILE);
      }
    }
  }

  private void drawPath(Graphics2D g, int x, int y, int w, int h) {
    g.setColor(new Color(118, 96, 58));
    g.fillRect(x, y, w, h);
    g.setColor(new Color(157, 132, 84));
    for (int px = x; px < x + w; px += 28) {
      for (int py = y; py < y + h; py += 18) {
        if (((px + py) / 18) % 2 == 0) g.fillRect(px, py, 14, 6);
      }
    }
  }

  private void drawWestGate(Graphics2D g) {
    g.setColor(new Color(245, 213, 125, 55));
    g.fillRect(0, 252, 42, 116);
    g.setColor(new Color(241, 221, 181));
    g.setFont(new Font("Dialog", Font.BOLD, 12));
    g.drawString("Wald", 8, 244);
  }

  private void drawBuilding(Graphics2D g, Building b) {
    g.setColor(new Color(0, 0, 0, 55));
    g.fillRect(b.x + 8, b.y + 10, b.w, b.h);
    g.setColor(b.wall);
    g.fillRect(b.x, b.y, b.w, b.h);
    g.setColor(b.wall.darker());
    for (int y = b.y + 10; y < b.y + b.h; y += 22) {
      g.drawLine(b.x, y, b.x + b.w, y);
    }
    g.setColor(b.roof);
    int[] xs = {b.x - 12, b.x + b.w / 2, b.x + b.w + 12};
    int[] ys = {b.y + 22, b.y - 26, b.y + 22};
    g.fillPolygon(xs, ys, 3);
    g.setColor(b.roof.darker());
    for (int x = b.x - 4; x < b.x + b.w; x += 18) {
      g.fillRect(x, b.y + 7, 12, 8);
    }
    g.setColor(nearestDoor() == b ? new Color(245, 213, 125) : new Color(45, 27, 19));
    g.fillRect(b.x + b.w / 2 - 10, b.y + b.h - 31, 20, 31);
    g.setColor(new Color(63, 42, 27));
    g.fillRect(b.x + 20, b.y + 34, 24, 22);
    g.fillRect(b.x + b.w - 44, b.y + 34, 24, 22);
    g.setColor(new Color(241, 221, 181));
    g.setFont(new Font("Dialog", Font.BOLD, 12));
    drawCentered(g, b.name, b.x + b.w / 2, b.y + b.h + 16);
  }

  private void drawTree(Graphics2D g, int x, int y) {
    g.setColor(new Color(75, 47, 28));
    g.fillRect(x - 6, y + 8, 12, 28);
    g.setColor(new Color(39, 79, 42));
    g.fillRect(x - 22, y - 20, 44, 20);
    g.fillRect(x - 30, y - 4, 60, 24);
    g.setColor(new Color(55, 108, 53));
    g.fillRect(x - 14, y - 30, 28, 18);
    g.fillRect(x + 10, y - 12, 18, 18);
  }

  private void drawNpc(Graphics2D g, Npc npc) {
    int bob = (int) Math.round(Math.sin(frame * 0.045 + npc.x * 0.03) * 2);
    int x = npc.x;
    int y = npc.y + bob;
    g.setColor(new Color(224, 186, 141));
    g.fillRect(x - 16, y + 2, 5, 17);
    g.fillRect(x + 11, y + 2, 5, 17);
    g.setColor(npc.state == QuestState.COMPLETE ? Color.GRAY : npc.color);
    g.fillRect(x - 12, y - 1, 24, 24);
    g.setColor(new Color(240, 201, 160));
    g.fillRect(x - 8, y - 17, 16, 16);
    g.setColor(new Color(255, 245, 207));
    g.setFont(new Font("Dialog", Font.BOLD, 13));
    drawCentered(g, npc.state == QuestState.AVAILABLE ? "!" : npc.state == QuestState.ACTIVE ? "?" : "ok", x, y - 27);
    drawCentered(g, npc.name, x, npc.y + 35);
  }

  private void drawPlayer(Graphics2D g) {
    int walk = (int) Math.round(Math.sin(player.walkCycle) * 7);
    int bob = player.moving ? -Math.abs(walk / 3) : (int) Math.round(Math.sin(frame * 0.05) * 1.2);
    int x = (int) Math.round(player.x);
    int y = (int) Math.round(player.y) + bob;
    int faceX = player.facingX >= 0 ? 1 : -1;
    double slash = Math.sin((player.attackAnim / 16.0) * Math.PI);
    double reach = Math.sin((player.interactAnim / 18.0) * Math.PI) * 12;

    g.setColor(new Color(0, 0, 0, 65));
    g.fillRect(x - 15, (int) player.y + 13, 30, 8);
    g.setColor(new Color(75, 85, 96));
    g.fillRect(x - 8 + walk / 2, y + 10, 6, 15);
    g.fillRect(x + 3 - walk / 2, y + 10, 6, 15);
    g.setColor(new Color(185, 197, 204));
    g.fillRect(x - 12, y - 8, 24, 25);
    g.setColor(new Color(66, 82, 93));
    g.fillRect(x - 7, y - 24, 14, 16);
    g.setColor(new Color(210, 216, 220));
    int swordX = x + faceX * (15 + (int) reach + (int) (slash * 22));
    g.fillRect(swordX, y - 8, 5, 34 + (int) (slash * 10));
    if (player.attackAnim > 0) {
      g.setColor(new Color(245, 213, 125, 175));
      g.setStroke(new BasicStroke(4));
      g.drawLine(x + faceX * 14, y - 20, x + faceX * 50, y + 20);
      g.drawLine(x + faceX * 18, y - 8, x + faceX * 42, y + 32);
    }
    g.setColor(new Color(187, 65, 65));
    g.fillRect(x - 12, y + 3, 20, 16);
  }

  private void drawMonster(Graphics2D g, Monster m) {
    if (m.hp <= 0) return;
    int idle = (int) Math.round(Math.sin(frame * 0.07 + m.homeX * 0.01) * 2);
    int x = (int) Math.round(m.x);
    int y = (int) Math.round(m.y) + idle;
    g.setColor(new Color(0, 0, 0, 60));
    g.fillRect(x - m.r - 5, (int) m.y + m.r, m.r * 2 + 10, 8);
    g.setColor(m.hit > 0 ? new Color(232, 208, 145) : m.color);
    g.fillRect(x - m.r, y - m.r, m.r * 2, m.r * 2);
    g.setColor(new Color(240, 217, 184));
    g.fillRect(x - 8, y - 7, 5, 5);
    g.fillRect(x + 4, y - 7, 5, 5);
    g.setColor(new Color(36, 26, 22));
    g.fillRect(x - 10, y + 6, 20, 4);
    g.setColor(new Color(215, 89, 75));
    g.fillRect(x - 14, y - m.r - 12, 28, 5);
    g.setColor(new Color(118, 179, 107));
    g.fillRect(x - 14, y - m.r - 12, (int) (28 * (m.hp / (double) m.maxHp)), 5);
  }

  private void drawItems(Graphics2D g) {
    for (Item herb : herbs) {
      if (herb.taken) continue;
      g.setColor(new Color(136, 211, 107));
      g.fillRect(herb.x - 6, herb.y - 6, 12, 12);
      g.setColor(new Color(223, 245, 188));
      g.fillRect(herb.x - 2, herb.y - 15, 4, 12);
    }
    for (Item log : logs) {
      if (log.taken) continue;
      g.setColor(new Color(122, 77, 46));
      g.fillRect(log.x - 13, log.y - 6, 26, 12);
      g.setColor(new Color(185, 130, 76));
      g.fillRect(log.x + 9, log.y - 6, 6, 12);
    }
  }

  private void drawWell(Graphics2D g) {
    g.setColor(new Color(0, 0, 0, 55));
    g.fillRect(445, 338, 70, 12);
    g.setColor(new Color(185, 192, 189));
    g.fillRect(446, 310, 68, 38);
    g.setColor(new Color(212, 218, 212));
    g.fillRect(452, 300, 56, 14);
    g.setColor(new Color(67, 80, 90));
    g.fillRect(462, 304, 36, 8);
    g.setColor(new Color(143, 152, 150));
    for (int x = 450; x < 514; x += 18) g.drawLine(x, 314, x, 345);
    g.drawLine(446, 324, 514, 324);
    g.drawLine(446, 336, 514, 336);
    g.setColor(new Color(111, 81, 53));
    g.fillRect(448, 264, 8, 48);
    g.fillRect(504, 264, 8, 48);
    g.fillRect(442, 264, 76, 8);
    g.setColor(new Color(169, 88, 59));
    int[] xs = {437, 480, 523};
    int[] ys = {264, 236, 264};
    g.fillPolygon(xs, ys, 3);
    g.setColor(new Color(47, 51, 53));
    g.drawLine(480, 272, 480, 296);
    g.setColor(new Color(139, 148, 150));
    g.fillRect(472, 296, 16, 14);
  }

  private void drawHint(Graphics2D g) {
    boolean near = nearestNpc() != null || nearestDoor() != null;
    near |= scene == Scene.INSIDE && dist(player.x, player.y, WIDTH / 2.0, HEIGHT - 74) < 50;
    near |= scene == Scene.FOREST && player.x > WIDTH - 76;
    if (scene == Scene.VILLAGE) {
      for (Item herb : herbs) near |= !herb.taken && dist(player.x, player.y, herb.x, herb.y) < 34;
      for (Item log : logs) near |= !log.taken && dist(player.x, player.y, log.x, log.y) < 34;
      Npc quest = activeQuest();
      near |= quest != null && quest.type == QuestType.WELL && questDone(quest);
    }
    if (!near) return;
    int x = (int) player.x;
    int y = (int) player.y;
    g.setColor(new Color(22, 18, 12, 220));
    g.fillRect(x - 58, y - 54, 116, 25);
    g.setColor(new Color(245, 213, 125));
    g.setFont(new Font("Dialog", Font.BOLD, 13));
    drawCentered(g, scene == Scene.FOREST && player.x > WIDTH - 76 ? "zum Dorf" : "E druecken", x, y - 37);
  }

  private void drawHud(Graphics2D g) {
    g.setColor(new Color(36, 32, 24, 235));
    g.fillRect(0, 0, WIDTH, 64);
    g.setColor(new Color(90, 72, 45));
    g.drawLine(0, 64, WIDTH, 64);
    g.setFont(new Font("Dialog", Font.BOLD, 14));
    g.setColor(new Color(242, 234, 216));
    g.drawString("Sir Alden  Level " + player.level + "  XP " + player.xp + "/" + player.nextXp, 18, 24);
    g.drawString("Heilkraut " + player.herbs + "  Holz " + player.wood + "  Steuerung: WASD/Pfeile, E, F", 18, 46);
    g.setColor(new Color(23, 18, 12, 225));
    g.fillRect(0, HEIGHT - 72, WIDTH, 72);
    g.setColor(new Color(217, 173, 85));
    g.setFont(new Font("Dialog", Font.BOLD, 16));
    g.drawString(title, 18, HEIGHT - 44);
    g.setColor(new Color(183, 170, 145));
    g.setFont(new Font("Dialog", Font.PLAIN, 14));
    g.drawString(message, 18, HEIGHT - 20);
  }

  private void drawCentered(Graphics2D g, String text, int x, int y) {
    Rectangle2D bounds = g.getFontMetrics().getStringBounds(text, g);
    g.drawString(text, x - (int) bounds.getWidth() / 2, y);
  }

  private static double clamp(double value, double min, double max) {
    return Math.max(min, Math.min(max, value));
  }

  private static double dist(double ax, double ay, double bx, double by) {
    return Math.hypot(ax - bx, ay - by);
  }

  private static boolean circleHitsRect(double cx, double cy, double radius, int x, int y, int w, int h) {
    double nx = clamp(cx, x, x + w);
    double ny = clamp(cy, y, y + h);
    return Math.hypot(cx - nx, cy - ny) < radius;
  }
}

enum Scene { VILLAGE, FOREST, INSIDE }
enum QuestState { AVAILABLE, ACTIVE, COMPLETE }
enum QuestType { HERBS, WOOD, WELL, TALK }

class Player {
  double x;
  double y;
  double vx = 0;
  double vy = 0;
  double facingX = 1;
  double facingY = 0;
  double speed = 2.45;
  int r = 12;
  int herbs = 0;
  int wood = 0;
  int xp = 0;
  int nextXp = 100;
  int level = 1;
  int interactAnim = 0;
  int attackAnim = 0;
  double walkCycle = 0;
  boolean moving = false;

  Player(double x, double y) {
    this.x = x;
    this.y = y;
  }
}

class Building {
  int x;
  int y;
  int w;
  int h;
  String name;
  Color roof;
  Color wall;

  Building(int x, int y, int w, int h, String name, Color roof, Color wall) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.name = name;
    this.roof = roof;
    this.wall = wall;
  }
}

class Npc {
  String name;
  String title;
  String text;
  int x;
  int y;
  Color color;
  int reward;
  QuestType type;
  QuestState state = QuestState.AVAILABLE;

  Npc(String name, String title, String text, int x, int y, Color color, int reward, QuestType type) {
    this.name = name;
    this.title = title;
    this.text = text;
    this.x = x;
    this.y = y;
    this.color = color;
    this.reward = reward;
    this.type = type;
  }
}

class Item {
  int x;
  int y;
  boolean taken = false;

  Item(int x, int y) {
    this.x = x;
    this.y = y;
  }
}

class Monster {
  String name;
  double x;
  double y;
  double homeX;
  double homeY;
  int r;
  int hp;
  int maxHp;
  int xp;
  int hit = 0;
  Color color;

  Monster(String name, int x, int y, int r, int hp, int xp, Color color) {
    this.name = name;
    this.x = x;
    this.y = y;
    this.homeX = x;
    this.homeY = y;
    this.r = r;
    this.hp = hp;
    this.maxHp = hp;
    this.xp = xp;
    this.color = color;
  }
}

class VisualEffect {
  double x;
  double y;
  int age = 0;
  int life = 38;
  Color color;
  String text;

  VisualEffect(double x, double y, Color color, String text) {
    this.x = x;
    this.y = y;
    this.color = color;
    this.text = text;
  }
}

class SoundManager {
  private static final float SAMPLE_RATE = 44100f;
  private boolean enabled = true;

  boolean isEnabled() {
    return enabled;
  }

  void toggle() {
    enabled = !enabled;
  }

  void play(String name) {
    if (!enabled) return;
    int[] notes;
    int duration;
    if ("attack".equals(name)) {
      notes = new int[] {360, 230};
      duration = 45;
    } else if ("hit".equals(name)) {
      notes = new int[] {180, 120};
      duration = 65;
    } else if ("pickup".equals(name)) {
      notes = new int[] {620, 840};
      duration = 70;
    } else if ("quest".equals(name)) {
      notes = new int[] {520, 680, 880};
      duration = 95;
    } else if ("level".equals(name)) {
      notes = new int[] {500, 650, 820, 1040};
      duration = 100;
    } else if ("save".equals(name)) {
      notes = new int[] {420, 620, 520};
      duration = 80;
    } else if ("transition".equals(name)) {
      notes = new int[] {260, 360, 460};
      duration = 90;
    } else {
      notes = new int[] {440};
      duration = 45;
    }

    new Thread(() -> playNotes(notes, duration), "game-sound").start();
  }

  private void playNotes(int[] notes, int durationMs) {
    try {
      AudioFormat format = new AudioFormat(SAMPLE_RATE, 8, 1, true, false);
      SourceDataLine line = AudioSystem.getSourceDataLine(format);
      line.open(format);
      line.start();
      for (int note : notes) writeTone(line, note, durationMs);
      line.drain();
      line.stop();
      line.close();
    } catch (Exception ex) {
      enabled = false;
    }
  }

  private void writeTone(SourceDataLine line, int hz, int durationMs) {
    int length = (int) (SAMPLE_RATE * durationMs / 1000.0);
    byte[] data = new byte[length];
    for (int i = 0; i < data.length; i++) {
      double t = i / SAMPLE_RATE;
      double fade = 1.0 - (i / (double) data.length);
      data[i] = (byte) (Math.sin(2.0 * Math.PI * hz * t) * 70 * fade);
    }
    line.write(data, 0, data.length);
  }
}

class PlayableWorld {
  String name = "Eigene Welt";
  String sourcePath = "";
  int width = 24;
  int height = 16;
  String[][] tiles = new String[height][width];
  final List<WorldAsset> assets = new ArrayList<>();
  final List<WorldObject> objects = new ArrayList<>();
  final List<WorldNpc> npcs = new ArrayList<>();
  final List<WorldQuest> quests = new ArrayList<>();

  WorldAsset asset(String id) {
    for (WorldAsset asset : assets) {
      if (asset.id.equals(id)) return asset;
    }
    return null;
  }
}

class WorldAsset {
  final String id;
  final String name;
  final String kind;
  final String texturePath;
  final Image image;
  final Color color;

  WorldAsset(String id, String name, String kind, String texturePath, Image image) {
    this.id = id;
    this.name = name;
    this.kind = kind;
    this.texturePath = texturePath;
    this.image = image;
    this.color = colorFor(id);
  }

  private static Color colorFor(String id) {
    if ("path".equals(id)) return new Color(118, 96, 58);
    if ("water".equals(id)) return new Color(60, 120, 160);
    if ("forest".equals(id)) return new Color(49, 80, 45);
    return new Color(81, 110, 60);
  }
}

class WorldObject {
  final String assetId;
  final String name;
  final int x;
  final int y;

  WorldObject(String assetId, String name, int x, int y) {
    this.assetId = assetId;
    this.name = name;
    this.x = x;
    this.y = y;
  }

  int pixelX() {
    return x * 32 + 16;
  }

  int pixelY() {
    return y * 32 + 72 + 16;
  }
}

class WorldNpc {
  final String name;
  final int x;
  final int y;
  final String dialog;

  WorldNpc(String name, int x, int y, String dialog) {
    this.name = name;
    this.x = x;
    this.y = y;
    this.dialog = dialog;
  }

  int pixelX() {
    return x * 32 + 16;
  }

  int pixelY() {
    return y * 32 + 72 + 16;
  }
}

class WorldQuest {
  final String title;
  final String text;
  final int rewardXp;

  WorldQuest(String title, String text, int rewardXp) {
    this.title = title;
    this.text = text;
    this.rewardXp = rewardXp;
  }
}

class SaveGame {
  String worldPath = "";
  String scene = "VILLAGE";
  double playerX = 470;
  double playerY = 340;
  int herbs = 0;
  int wood = 0;
  int xp = 0;
  int nextXp = 100;
  int level = 1;

  String toJson() {
    return "{\n"
        + "  \"worldPath\": \"" + escape(worldPath) + "\",\n"
        + "  \"scene\": \"" + escape(scene) + "\",\n"
        + "  \"playerX\": " + playerX + ",\n"
        + "  \"playerY\": " + playerY + ",\n"
        + "  \"herbs\": " + herbs + ",\n"
        + "  \"wood\": " + wood + ",\n"
        + "  \"xp\": " + xp + ",\n"
        + "  \"nextXp\": " + nextXp + ",\n"
        + "  \"level\": " + level + "\n"
        + "}\n";
  }

  static SaveGame load(File file) throws IOException {
    String json = Files.readString(file.toPath(), StandardCharsets.UTF_8);
    SaveGame save = new SaveGame();
    save.worldPath = matchString(json, "worldPath", "");
    save.scene = matchString(json, "scene", "VILLAGE");
    save.playerX = matchDouble(json, "playerX", 470);
    save.playerY = matchDouble(json, "playerY", 340);
    save.herbs = matchInt(json, "herbs", 0);
    save.wood = matchInt(json, "wood", 0);
    save.xp = matchInt(json, "xp", 0);
    save.nextXp = matchInt(json, "nextXp", 100);
    save.level = matchInt(json, "level", 1);
    return save;
  }

  private static String matchString(String json, String key, String fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(json);
    return matcher.find() ? unescape(matcher.group(1)) : fallback;
  }

  private static int matchInt(String json, String key, int fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*(-?\\d+)").matcher(json);
    return matcher.find() ? Integer.parseInt(matcher.group(1)) : fallback;
  }

  private static double matchDouble(String json, String key, double fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)").matcher(json);
    return matcher.find() ? Double.parseDouble(matcher.group(1)) : fallback;
  }

  private static String escape(String value) {
    return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
  }

  private static String unescape(String value) {
    return value.replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\");
  }
}

class PlayableWorldLoader {
  static PlayableWorld load(File file) throws IOException {
    String json = Files.readString(file.toPath(), StandardCharsets.UTF_8);
    PlayableWorld world = new PlayableWorld();
    world.name = matchString(json, "name", stripExtension(file.getName()));
    world.sourcePath = file.getAbsolutePath();
    world.width = matchInt(json, "width", 24);
    world.height = matchInt(json, "height", 16);
    world.tiles = new String[world.height][world.width];
    for (int y = 0; y < world.height; y++) {
      for (int x = 0; x < world.width; x++) world.tiles[y][x] = "grass";
    }

    for (String item : objectSnippets(matchBlock(json, "assets"))) {
      String id = matchString(item, "id", "asset_" + world.assets.size());
      String name = matchString(item, "name", id);
      String kind = matchString(item, "kind", "TERRAIN");
      String texturePath = matchString(item, "texturePath", "");
      BufferedImage image = null;
      if (!texturePath.isEmpty()) {
        File texture = new File(texturePath);
        if (texture.isFile()) image = ImageIO.read(texture);
      }
      world.assets.add(new WorldAsset(id, name, kind, texturePath, image));
    }
    if (world.asset("grass") == null) world.assets.add(new WorldAsset("grass", "Gras", "TERRAIN", "", null));

    Matcher rowMatcher = Pattern.compile("\\[(.*?)\\]", Pattern.DOTALL).matcher(matchBlock(json, "tiles"));
    int y = 0;
    while (rowMatcher.find() && y < world.height) {
      Matcher tileMatcher = Pattern.compile("\"(.*?)\"").matcher(rowMatcher.group(1));
      int x = 0;
      while (tileMatcher.find() && x < world.width) {
        world.tiles[y][x] = unescape(tileMatcher.group(1));
        x++;
      }
      y++;
    }

    for (String item : objectSnippets(matchBlock(json, "objects"))) {
      world.objects.add(new WorldObject(matchString(item, "assetId", "tree"), matchString(item, "name", "Objekt"),
          matchInt(item, "x", 0), matchInt(item, "y", 0)));
    }
    for (String item : objectSnippets(matchBlock(json, "npcs"))) {
      world.npcs.add(new WorldNpc(matchString(item, "name", "NPC"), matchInt(item, "x", 0), matchInt(item, "y", 0),
          matchString(item, "dialog", "")));
    }
    for (String item : objectSnippets(matchBlock(json, "quests"))) {
      world.quests.add(new WorldQuest(matchString(item, "title", "Quest"), matchString(item, "text", ""),
          matchInt(item, "rewardXp", 25)));
    }
    return world;
  }

  private static String stripExtension(String value) {
    int dot = value.lastIndexOf('.');
    return dot > 0 ? value.substring(0, dot) : value;
  }

  private static List<String> objectSnippets(String block) {
    List<String> snippets = new ArrayList<>();
    Matcher matcher = Pattern.compile("\\{(.*?)\\}", Pattern.DOTALL).matcher(block);
    while (matcher.find()) snippets.add(matcher.group(1));
    return snippets;
  }

  private static String matchBlock(String json, String key) {
    String token = "\"" + key + "\"";
    int keyIndex = json.indexOf(token);
    if (keyIndex < 0) return "";
    int start = json.indexOf('[', keyIndex + token.length());
    if (start < 0) return "";
    int depth = 0;
    boolean inString = false;
    boolean escaped = false;
    for (int i = start; i < json.length(); i++) {
      char c = json.charAt(i);
      if (escaped) {
        escaped = false;
      } else if (c == '\\') {
        escaped = true;
      } else if (c == '"') {
        inString = !inString;
      } else if (!inString && c == '[') {
        depth++;
      } else if (!inString && c == ']') {
        depth--;
        if (depth == 0) return json.substring(start + 1, i);
      }
    }
    return "";
  }

  private static String matchString(String json, String key, String fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(json);
    return matcher.find() ? unescape(matcher.group(1)) : fallback;
  }

  private static int matchInt(String json, String key, int fallback) {
    Matcher matcher = Pattern.compile("\"" + key + "\"\\s*:\\s*(\\d+)").matcher(json);
    return matcher.find() ? Integer.parseInt(matcher.group(1)) : fallback;
  }

  private static String unescape(String value) {
    return value.replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\");
  }
}
